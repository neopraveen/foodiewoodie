package com.ril.jioads.model;

import java.util.Map;

public class UserAdditionalProfileModel {
    public String mobileUid;
    public Map<String, String> profiles;
}
