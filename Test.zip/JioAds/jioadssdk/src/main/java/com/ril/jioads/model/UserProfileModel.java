package com.ril.jioads.model;

import java.util.HashMap;
import java.util.Map;

public class UserProfileModel {
    public String mobileUid;
    public Map<String, String> profiles;
}
