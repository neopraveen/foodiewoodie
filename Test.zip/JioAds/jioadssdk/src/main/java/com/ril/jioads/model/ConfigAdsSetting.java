package com.ril.jioads.model;

import com.ril.jioads.utils.ExceptionHandler;

/**
 * Created by ProBook on 10/5/2017.
 */

public class ConfigAdsSetting {
    public boolean flag;
    public int reattemtCount;
    public int reattemptIntervalInMin;
    public int scheduleIntervalInMin;
    public String dayWise;
    public int dayIntervals;

    int[] getSupportDays() {
        if (dayWise == null || dayWise.equals(""))
            return new int[0];
        String[] supportDaysString = dayWise.split(",");
        int[] supportDays = new int[supportDaysString.length];
        for (int i = 0; i < supportDaysString.length; i++) {
            try {
                supportDays[i] = Integer.parseInt(supportDaysString[i]);
            } catch (Exception e) {
                ExceptionHandler.handle(e);
            }
        }
        return supportDays;
    }
}
