package com.ril.jioads.model;

import java.util.List;

/**
 * Created by ProBook on 1/5/2018.
 */

public class ActiveCampaignModel {
    public List<AdsCampaignModel> activeCampaigns;
    public String token;
}
