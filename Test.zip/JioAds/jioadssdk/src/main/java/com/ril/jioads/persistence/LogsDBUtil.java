package com.ril.jioads.persistence;

import android.content.Context;

import com.ril.jioads.model.EventLoggerModel;

import java.util.Iterator;
import java.util.List;

public class LogsDBUtil {
    public static void addLogs(EventLoggerModel eventLoggerModel) {

    }

    public static void addLogs(List<EventLoggerModel> eventLoggerModelList) {

    }

    public static List<EventLoggerModel> getPendingLogs(Context applicationContext) {
        return null;
    }

    public static void clearAllPendingLogs(Context applicationContext) {

    }

    public static void markLogsSuccessful(List<EventLoggerModel> updatedLoggerModelList, Context applicationContext) {
        List<EventLoggerModel> allPendingLogs = getPendingLogs(applicationContext);
        if (allPendingLogs != null && allPendingLogs.size() > 0 && updatedLoggerModelList != null && updatedLoggerModelList.size() > 0) {
            Iterator<EventLoggerModel> pendingLogsIterator = allPendingLogs.iterator();
            while (pendingLogsIterator.hasNext()) {
                EventLoggerModel pendingLoggerModel = pendingLogsIterator.next();
                Iterator<EventLoggerModel> updatedLoggerModeIterator = updatedLoggerModelList.iterator();
                while (updatedLoggerModeIterator.hasNext()) {
                    EventLoggerModel eventLoggerModel = updatedLoggerModeIterator.next();
                    if (pendingLoggerModel.campaingId.equals(eventLoggerModel.campaingId) && pendingLoggerModel.logTime == eventLoggerModel.logTime) {
                        pendingLogsIterator.remove();
                        break;
                    }
                }
            }
        }
        clearAllPendingLogs(applicationContext);
        addLogs(allPendingLogs);
    }


}
