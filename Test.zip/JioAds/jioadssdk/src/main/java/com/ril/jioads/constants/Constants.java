package com.ril.jioads.constants;

/**
 * Created by ProBook on 8/7/2017.
 */

public interface Constants {
    String REGISTRATION_SCN = "registration";
    String ADVERTISEMENT_BROADCAST_EVENTS = "AdvertisementEvents";
    String DATA = "DATA";
    String TESTING_STATUS = "testing_status";
    String FB_TOKEN = "regId";
    String CAMPAIGN_COUNTER_PRE = "campaign_counter_";

    String ACTIVITY_TYPE_CLICK = "Clicked";
    String ACTIVITY_TYPE_VIEW = "Viewed";
    String ACTIVITY_TYPE_DELIVERED = "Delivered";

    String SHOW_ADS_ON_SYSTEM_EVENTS = "saonse";
    String ADS_COFIG_SCN = "adscnfg";
    String ADS_TOKEN_SCN = "adstoken";
    String ADS_UUID_SCN = "adsuuid";
    String ADS_MOBILE_UID_SCN = "adsmobileuid";
    String API_CALL_RUNNING = "apicallrunning";
    String SCHEDULE_PROFILE_UPDATE = "schdlprflupd";
    String USER_DETAILS = "userdetails";
    String TAG = "JIOADS";
    String USER_PROFILE = "user_profile";
    String USER_PROFILE_UPDATED = "user_profile_updated";
}
