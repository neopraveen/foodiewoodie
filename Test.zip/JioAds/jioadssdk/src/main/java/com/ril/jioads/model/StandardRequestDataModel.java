package com.ril.jioads.model;

public class StandardRequestDataModel {
    public String uid;
    public String data;
}