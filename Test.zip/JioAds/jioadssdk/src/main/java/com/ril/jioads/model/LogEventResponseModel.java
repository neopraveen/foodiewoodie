package com.ril.jioads.model;

/**
 * Created by ProBook on 8/31/2017.
 */

public class LogEventResponseModel {
    public String status;
}
