package com.ril.jioads.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by ProBook on 1/5/2018.
 */

public class AdsCampaignModel implements Parcelable {
    public static final Creator<AdsCampaignModel> CREATOR = new Creator<AdsCampaignModel>() {
        @Override
        public AdsCampaignModel createFromParcel(Parcel in) {
            return new AdsCampaignModel(in);
        }

        @Override
        public AdsCampaignModel[] newArray(int size) {
            return new AdsCampaignModel[size];
        }
    };
    public String campaignTitle;
    public String status;
    public String triggerType;
    public String triggeredBy;
    public String campaignId;
    public String mediasetId;
    public String minCallDuration;
    public String usersRoaming;
    public String redirectUrl;
    public String appName;
    public String profile;
    public String campaignType;
    public String mediaType;
    public String surveyId;
    public String mediasetUrl;
    public AdsCampaignScheduleModel scheduleCampaign;

    protected AdsCampaignModel(Parcel in) {
        campaignTitle = in.readString();
        status = in.readString();
        triggerType = in.readString();
        triggeredBy = in.readString();
        campaignId = in.readString();
        mediasetId = in.readString();
        minCallDuration = in.readString();
        usersRoaming = in.readString();
        redirectUrl = in.readString();
        appName = in.readString();
        profile = in.readString();
        campaignType = in.readString();
        mediaType = in.readString();
        surveyId = in.readString();
        mediasetUrl = in.readString();
        scheduleCampaign = in.readParcelable(AdsCampaignScheduleModel.class.getClassLoader());
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(campaignTitle);
        dest.writeString(status);
        dest.writeString(triggerType);
        dest.writeString(triggeredBy);
        dest.writeString(campaignId);
        dest.writeString(mediasetId);
        dest.writeString(minCallDuration);
        dest.writeString(usersRoaming);
        dest.writeString(redirectUrl);
        dest.writeString(appName);
        dest.writeString(profile);
        dest.writeString(campaignType);
        dest.writeString(mediaType);
        dest.writeString(surveyId);
        dest.writeString(mediasetUrl);
        dest.writeParcelable(scheduleCampaign, flags);
    }
}
