package com.ril.jioads.utils;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ril.jioads.constants.Constants;
import com.ril.jioads.persistence.SharedPreferenceStore;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class ProfileManagingUtils {

    public static void saveProfile(Context context, String profileString) {
        if (isProfileUpdated(context, profileString)) {
            SharedPreferenceStore.storeValue(context, Constants.USER_PROFILE, profileString);
            markProfileUpdated(context, true);
        }
    }

    public static boolean isProfileUpdated(Context context) {
        return SharedPreferenceStore.getValue(context, Constants.USER_PROFILE_UPDATED, false);
    }

    private static void markProfileUpdated(Context context, boolean profileUpdated) {
        SharedPreferenceStore.storeValue(context, Constants.USER_PROFILE_UPDATED, profileUpdated);
    }

    public static String getProfile(Context context) {
        String profileString = SharedPreferenceStore.getValue(context, Constants.USER_PROFILE, "");
        return profileString;
    }

    public static Map<String, String> getProfileMap(Context context) {
        String profileString = SharedPreferenceStore.getValue(context, Constants.USER_PROFILE, "");
        Type type = new TypeToken<Map<String, String>>(){}.getType();
        Map<String, String> myMap = new Gson().fromJson(profileString, type);
        return myMap;
    }

    public static boolean isProfileUpdated(Context context, String profileString) {
        String oldProfileString = getProfile(context);
        if (oldProfileString != null && profileString != null) {
            if (oldProfileString.equals(profileString))
                return false;
        }
        return true;
    }
}
