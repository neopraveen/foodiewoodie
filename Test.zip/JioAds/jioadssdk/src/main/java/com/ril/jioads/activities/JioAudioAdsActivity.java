package com.ril.jioads.activities;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import com.ril.jio.jioads.R;

public class JioAudioAdsActivity extends Activity implements OnCompletionListener, OnBufferingUpdateListener, MediaPlayer.OnPreparedListener {
    private final Handler handler = new Handler();
    String url = "https://www.hrupin.com/wp-content/uploads/mp3/testsong_20_sec.mp3";
    int totalTime;
    TextView mediaRemainsTextView;
    private SeekBar seekBarProgress;
    private MediaPlayer mediaPlayer;
    private int mediaFileLengthInMilliseconds; // this value contains the song duration in milliseconds. Look at getDuration() method in MediaPlayer class

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jio_audio_ads);
        initView();
        initMediaPlayer();
    }

    private void initMediaPlayer() {
        try {
            mediaPlayer.setDataSource(url);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initView() {
        seekBarProgress = (SeekBar) findViewById(R.id.audio_ads_seekbar);
        mediaRemainsTextView = (TextView) findViewById(R.id.audio_remaining_time);
        seekBarProgress.setMax(99); // It means 100% .0-99
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setOnPreparedListener(this);
        mediaPlayer.setOnBufferingUpdateListener(this);
        mediaPlayer.setOnCompletionListener(this);
    }

    private void primarySeekBarProgressUpdater() {
        int progress = getProgress();
        Log.e("AudioAdsLogs", "pSBPU....-" + progress);
        seekBarProgress.setProgress(progress);
        updateRemainingTime();
        if (mediaPlayer.isPlaying()) {
            Runnable notification = new Runnable() {
                public void run() {
                    primarySeekBarProgressUpdater();
                }
            };
            handler.postDelayed(notification, 1000);
        }
    }

    private int getProgress() {
        return (int) (((float) mediaPlayer.getCurrentPosition() / mediaFileLengthInMilliseconds) * 100);
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        });
    }

    @Override
    public void onBufferingUpdate(MediaPlayer mp, int percent) {
        seekBarProgress.setSecondaryProgress(percent);
    }

    private void updateRemainingTime() {
        if (totalTime >= 0 && totalTime < 100)
            mediaRemainsTextView.setText("" + totalTime--);
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        mediaFileLengthInMilliseconds = mediaPlayer.getDuration(); // gets the song length in milliseconds from URL
        totalTime = mediaFileLengthInMilliseconds / 1000;
        if (!mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
        primarySeekBarProgressUpdater();
        Log.e("AudioAdsLogs", "onPrepared..-" + mediaFileLengthInMilliseconds);
    }
}