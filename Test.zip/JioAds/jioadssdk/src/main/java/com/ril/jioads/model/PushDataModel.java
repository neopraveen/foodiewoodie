package com.ril.jioads.model;

import android.os.Parcel;
import android.os.Parcelable;

public class PushDataModel implements Parcelable {

    public static final Creator<PushDataModel> CREATOR = new Creator<PushDataModel>() {
        @Override
        public PushDataModel createFromParcel(Parcel in) {
            return new PushDataModel(in);
        }

        @Override
        public PushDataModel[] newArray(int size) {
            return new PushDataModel[size];
        }
    };
    private static final long serialVersionUID = 1L;
    public String title;
    public String campaignId;
    public String logoImgUrl;
    public String bodyImgUrl;
    public String txtMsg;
    public String deepLinkUrl;
    public String extLinkUrl;
    public String fMsg;
    public String appName;

    public PushDataModel() {

    }

    protected PushDataModel(Parcel in) {
        title = in.readString();
        campaignId = in.readString();
        logoImgUrl = in.readString();
        bodyImgUrl = in.readString();
        txtMsg = in.readString();
        deepLinkUrl = in.readString();
        extLinkUrl = in.readString();
        fMsg = in.readString();
        appName = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(campaignId);
        dest.writeString(logoImgUrl);
        dest.writeString(bodyImgUrl);
        dest.writeString(txtMsg);
        dest.writeString(deepLinkUrl);
        dest.writeString(extLinkUrl);
        dest.writeString(fMsg);
        dest.writeString(appName);
    }
}
