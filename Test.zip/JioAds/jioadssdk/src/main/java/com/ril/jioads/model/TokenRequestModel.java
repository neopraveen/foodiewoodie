package com.ril.jioads.model;

/**
 * Created by ProBook on 12/29/2017.
 */

public class TokenRequestModel {
    String uid;
    String reqFrom;
    String version;
    String appName;

    public TokenRequestModel(String uid, String reqFrom, String version, String appName) {
        this.uid = uid;
        this.reqFrom = reqFrom;
        this.version = version;
        this.appName = appName;
    }
}
