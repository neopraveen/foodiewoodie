package com.ril.jioads.utils;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.text.Html;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ril.jio.jioads.R;
import com.ril.jioads.firebase.app.Config;
import com.ril.jioads.model.NotificationModel;
import com.ril.jioads.model.PushDataModel;
import com.ril.jioads.persistence.SharedPreferenceStore;
import com.ril.jioads.recievers.JioPushNotificationReceiver;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by Ravi on 31/03/15.
 */
public class NotificationUtils {

    private static final int DELETE_NOTIFICATION_REQUEST_CODE = 10;
    private static String TAG = NotificationUtils.class.getSimpleName();

    private Context mContext;

    public NotificationUtils(Context mContext) {
        this.mContext = mContext;
    }

    /**
     * Method checks if the app is in background or not
     */
    public static boolean isAppIsInBackground(Context context) {
        String userJsonData = SharedPreferenceStore.getValue(context, "USER_DATA", "");
        Type listType = new TypeToken<List<PushDataModel>>() {
        }.getType();
        PushDataModel userData = new Gson().fromJson(userJsonData, PushDataModel.class);


        String response = "";
        SharedPreferenceStore.storeValue(context, "USER_DATA", response.toString());
        boolean isInBackground = true;
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT_WATCH) {
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
                if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    for (String activeProcess : processInfo.pkgList) {
                        if (activeProcess.equals(context.getPackageName())) {
                            isInBackground = false;
                        }
                    }
                }
            }
        } else {
            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
            ComponentName componentInfo = taskInfo.get(0).topActivity;
            if (componentInfo.getPackageName().equals(context.getPackageName())) {
                isInBackground = false;
            }
        }

        return isInBackground;
    }

    // Clears notification tray messages
    public static void clearNotifications(Context context) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancelAll();
    }

    public static long getTimeMilliSec(String timeStamp) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date date = format.parse(timeStamp);
            return date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public void showNotificationMessage(String title, String message, String timeStamp, Intent intent) {
        // notification icon
        final int icon = R.drawable.ic_launcher;

        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        final PendingIntent resultPendingIntent =
                PendingIntent.getActivity(
                        mContext,
                        0,
                        intent,
                        PendingIntent.FLAG_CANCEL_CURRENT
                );

        final NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                mContext);


        showSmallNotification(mBuilder, icon, title, message, timeStamp, resultPendingIntent, null);

    }

    public void showNotificationMessage(final NotificationModel notificationModel, Intent intent) {
        switch (notificationModel.mediaType) {
            case NotificationModel.MEDIA_TYPE_TEXT:
                handleTextNotification(notificationModel, intent);
                break;
            case NotificationModel.MEDIA_TYPE_IMAGE:
                fetchImage(notificationModel, intent);
                break;
            default:
                break;
        }
    }

    private void handleTextNotification(NotificationModel notificationModel, Intent intent) {
        if (!AdsHelperUtils.isEmpty(notificationModel.title) && !AdsHelperUtils.isEmpty(notificationModel.message)) {
            showNotificationMessage(notificationModel.title, notificationModel.message, "", intent);
        }
    }

    private void fetchImage(final NotificationModel pushDataModel, final Intent intent) {
        if (pushDataModel != null && pushDataModel.imgUrl != null && !pushDataModel.imgUrl.equals("")) {
            new AsyncTask<Void, Void, Void>() {

                @Override
                protected Void doInBackground(Void... voids) {
                    pushDataModel.imgBitmap = getBitmapFromURL(pushDataModel.imgUrl);
                    pushDataModel.iconBitmap = getBitmapFromURL(pushDataModel.iconUrl);
                    return null;
                }

                @Override
                protected void onPostExecute(Void vVoid) {
                    showNotificationMessage(pushDataModel.title, pushDataModel.message, null, intent, pushDataModel.imgBitmap, pushDataModel.iconBitmap);
                }
            }.execute();
        }
    }

    public void showNotificationMessage(final String title, final String message, final String timeStamp, Intent intent, Bitmap bitmap, Bitmap iconBitmap) {
        // Check for empty push message
        if (TextUtils.isEmpty(message))
            return;


        // notification icon
        final int icon = R.drawable.ic_launcher;

        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        final PendingIntent resultPendingIntent =
                PendingIntent.getActivity(
                        mContext,
                        0,
                        intent,
                        PendingIntent.FLAG_CANCEL_CURRENT
                );

        final NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                mContext);


        if (bitmap != null) {
            showBigNotification(bitmap, mBuilder, icon, title, message, timeStamp, resultPendingIntent, null, iconBitmap);
        } else {
            showSmallNotification(mBuilder, icon, title, message, timeStamp, resultPendingIntent, null);
        }
//            }
//        } else {
//            showSmallNotification(mBuilder, icon, title, message, timeStamp, resultPendingIntent, null);
//            playNotificationSound();
//        }
    }

    private void showSmallNotification(NotificationCompat.Builder mBuilder, int icon, String title, String message, String timeStamp, PendingIntent resultPendingIntent, Uri alarmSound) {
        NotificationCompat.InboxStyle inboxStyle = new NotificationCompat.InboxStyle();
        inboxStyle.addLine(message);
        Notification notification;
        String id = "my_channel_01";
        getNotificationChannel(mContext);
        notification = mBuilder.setSmallIcon(icon).setTicker(title).setWhen(0)
                .setAutoCancel(true)
                .setContentTitle(title)
                .setContentIntent(resultPendingIntent)
                .setStyle(inboxStyle)
                .setSmallIcon(R.drawable.ic_launcher)
                .setDeleteIntent(getDeleteNotificationListener())
                .setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), icon))
                .setContentText(message)
                .setChannelId(id)
                .build();

        NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(Config.NOTIFICATION_ID, notification);
    }

    private void getNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            String id = "my_channel_01";
            CharSequence name = "Jio Ads";
            String description = "Ads by Jio Engage";

            int importance = NotificationManager.IMPORTANCE_LOW;

            NotificationChannel mChannel = new NotificationChannel(id, name, importance);
            mChannel.setDescription(description);
            mChannel.enableLights(true);
            mNotificationManager.createNotificationChannel(mChannel);
        }
    }

    private void showBigNotification(Bitmap bitmap, NotificationCompat.Builder mBuilder, int icon, String title, String message, String timeStamp, PendingIntent resultPendingIntent, Uri alarmSound, Bitmap iconBitmap) {
        NotificationCompat.BigPictureStyle bigPictureStyle = new NotificationCompat.BigPictureStyle();
        bigPictureStyle.setBigContentTitle(title);
        bigPictureStyle.setSummaryText(Html.fromHtml(message).toString());
        bigPictureStyle.bigPicture(bitmap);
        NotificationCompat.Builder notificationBuilder = mBuilder.setSmallIcon(icon).setTicker(title).setWhen(0)
                .setAutoCancel(true)
                .setContentTitle(title)
                .setContentIntent(resultPendingIntent)
                .setStyle(bigPictureStyle)
                .setDeleteIntent(getDeleteNotificationListener())
                .setSmallIcon(R.drawable.ic_launcher)
                .setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), icon))
                .setContentText(message);
        if (iconBitmap != null)
            notificationBuilder.setLargeIcon(iconBitmap);
        Notification notification = notificationBuilder.build();

        NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(Config.NOTIFICATION_ID_BIG_IMAGE, notification);
    }

    private PendingIntent getDeleteNotificationListener() {
        Intent intent = new Intent(mContext, JioPushNotificationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(mContext, DELETE_NOTIFICATION_REQUEST_CODE, intent, 0);
        return pendingIntent;
    }

    /**
     * Downloading push notification image before displaying it in
     * the notification tray
     */
    public Bitmap getBitmapFromURL(String strURL) {
        try {
            URL url = new URL(strURL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Playing notification sound
    public void playNotificationSound() {
        try {
            Uri alarmSound = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE
                    + "://" + mContext.getPackageName() + "/raw/notification");
            Ringtone r = RingtoneManager.getRingtone(mContext, alarmSound);
            r.play();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
