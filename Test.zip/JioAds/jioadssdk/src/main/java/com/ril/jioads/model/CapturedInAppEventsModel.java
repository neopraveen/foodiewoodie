package com.ril.jioads.model;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by ProBook on 8/31/2017.
 */

public class CapturedInAppEventsModel {
    public String campaignID;
    public String campaignName;
    public String triggerType;
    public String activity;
    public String eventTime;

    public void setEventTime(Date date) {
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
        this.eventTime = timeStamp;
    }
}
