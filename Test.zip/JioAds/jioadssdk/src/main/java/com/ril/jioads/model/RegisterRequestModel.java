package com.ril.jioads.model;

import java.util.Map;

/**
 * Created by ProBook on 1/4/2018.
 */

public class RegisterRequestModel {
    public String appName;
    public String imei;
    public String endPointUri;
    public String userAuth;
    public String userKey;
    public String mobileUid;
    public String platform;
    public String version;
    public Map<String, String> profiles;

//    public String mobile;
//    public String circle;
//    public String mail;
//    public String customerId;
//    public String subscriberId;
//    public String userType;
//    public String userAuth;
//    public String userKey;
//    public String imsi;
//    public String activationDate;
//    public String reqFrom = "ANDROID";
//    public RegisterProfile profiles;
//    public String uid;
//    public String oldToken;
//
//    public static class RegisterProfile {
//        public String circle;
//        public String customer_type;
//        public String user_type;
//        public String version;
//        public String platform;
//    }
}

