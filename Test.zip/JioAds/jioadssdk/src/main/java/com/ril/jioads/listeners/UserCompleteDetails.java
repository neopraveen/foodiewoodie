package com.ril.jioads.listeners;

import java.util.Map;

/**
 * Created by ProBook on 1/8/2018.
 */

public class UserCompleteDetails {
    public Map<String, String> profiles;
    String appName;
    String appVersion;
    String imeiNumber;


    public UserCompleteDetails(String appName, String appVersion, String imeiNumber) {
        this.appName = appName;
        this.appVersion = appVersion;
        this.imeiNumber = imeiNumber;
    }

    public UserCompleteDetails() {

    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getImeiNumber() {
        return imeiNumber;
    }

    public void setImeiNumber(String imeiNumber) {
        this.imeiNumber = imeiNumber;
    }

}
