package com.ril.jioads.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by ProBook on 8/8/2017.
 */

public class ScheduleCampaignTime implements Parcelable{
    public int id;
    public String starttime;
    public String endtime;
    public String scheduledtype;
    public String startdate;
    public String enddate;
    public String repeatType;
    public String repeatTypeFrequency;
    public String repeatWeeklyDays;
    public String repeatMonthlyDates;
    public String repeatMonthlyDays;
    public String scheduleonetimeon;
    public String campaignFrequency;
    public String recurringDate;
    public String campaignMstBean;
    public String scheduleCampaignTime;
    public String scheduleCampaign;

    protected ScheduleCampaignTime(Parcel in) {
        id = in.readInt();
        starttime = in.readString();
        endtime = in.readString();
        scheduledtype = in.readString();
        startdate = in.readString();
        enddate = in.readString();
        repeatType = in.readString();
        repeatTypeFrequency = in.readString();
        repeatWeeklyDays = in.readString();
        repeatMonthlyDates = in.readString();
        repeatMonthlyDays = in.readString();
        scheduleonetimeon = in.readString();
        campaignFrequency = in.readString();
        recurringDate = in.readString();
        campaignMstBean = in.readString();
        scheduleCampaignTime = in.readString();
        scheduleCampaign = in.readString();
    }

    public static final Creator<ScheduleCampaignTime> CREATOR = new Creator<ScheduleCampaignTime>() {
        @Override
        public ScheduleCampaignTime createFromParcel(Parcel in) {
            return new ScheduleCampaignTime(in);
        }

        @Override
        public ScheduleCampaignTime[] newArray(int size) {
            return new ScheduleCampaignTime[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(starttime);
        dest.writeString(endtime);
        dest.writeString(scheduledtype);
        dest.writeString(startdate);
        dest.writeString(enddate);
        dest.writeString(repeatType);
        dest.writeString(repeatTypeFrequency);
        dest.writeString(repeatWeeklyDays);
        dest.writeString(repeatMonthlyDates);
        dest.writeString(repeatMonthlyDays);
        dest.writeString(scheduleonetimeon);
        dest.writeString(campaignFrequency);
        dest.writeString(recurringDate);
        dest.writeString(campaignMstBean);
        dest.writeString(scheduleCampaignTime);
        dest.writeString(scheduleCampaign);
    }
}
