package com.ril.jioads.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.ril.jioads.constants.Constants;
import com.ril.jioads.model.NotificationModel;
import com.ril.jioads.utils.JioAdsLoggingUtils;

import java.util.Date;

/**
 * Created by ProBook on 8/8/2017.
 */

public class JioBrowserAdsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        openExternalLink();
        finish();
    }

    private void openExternalLink() {
        if (getIntent().hasExtra(Constants.DATA)) {
            NotificationModel notificationModel = getIntent().getParcelableExtra(Constants.DATA);
            if (notificationModel != null) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW);
                JioAdsLoggingUtils.logEvent(Constants.ACTIVITY_TYPE_CLICK, new Date(), notificationModel, getApplicationContext());
                browserIntent.setData(Uri.parse(notificationModel.deeplink));
                startActivity(browserIntent);
            }
        }
    }

}