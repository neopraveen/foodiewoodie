package com.ril.jioads.model;

/**
 * Created by ProBook on 10/5/2017.
 */

public class ConfigPostData {
    public String uid;
    public String appName;
    public String syncTime;
    public String requestFrom;
    public String version;
}
