package com.ril.jioads.cryptoutils;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AES {
  static String IV = "37303631373337333233333133323333";
  static String plaintext = "It works"; /*Note null padding*/
  static String encryptionKey = "37303631373337333233333133323333";
  public static void main(String [] args) {
    try {
      
   /*   System.out.println("==Java==");
      System.out.println("plain:   " + plaintext);

      byte[] cipher = encrypt(plaintext, encryptionKey);

      System.out.print("cipher:  ");
      for (int i=0; i<cipher.length; i++)
        System.out.print(new Integer(cipher[i])+" ");
      System.out.println("");

      String decrypted = decrypt(cipher, encryptionKey);

      System.out.println("decrypt: " + decrypted);
*/
  /*  	String plainText = "Hello, World! This is a Java/Javascript AES test.";
    	SecretKey key = new SecretKeySpec(
    	    Base64.decodeBase64("u/Gu5posvwDsXUnV5Zaq4g=="), "AES");
    	AlgorithmParameterSpec iv = new IvParameterSpec(
    	    Base64.decodeBase64("5D9r9ZVzEYYgha93/aUK2w==")); 
    	Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
    	cipher.init(Cipher.ENCRYPT_MODE, key, iv);
    	System.out.println(Base64.encodeBase64String(cipher.doFinal(
    	    plainText.getBytes("UTF-8"))));*/
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }

  public static byte[] encrypt(String plainText, String encryptionKey) throws Exception {
    Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
    SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), "AES");
    cipher.init(Cipher.ENCRYPT_MODE, key,new IvParameterSpec(IV.getBytes("UTF-8")));
    return cipher.doFinal(plainText.getBytes("UTF-8"));
  }

  public static String decrypt(byte[] cipherText, String encryptionKey) throws Exception{
    Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
    SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), "AES");
    cipher.init(Cipher.DECRYPT_MODE, key,new IvParameterSpec(IV.getBytes("UTF-8")));
    return new String(cipher.doFinal(cipherText),"UTF-8");
  }
  
}