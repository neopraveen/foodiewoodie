package com.ril.jioads.model;

import android.content.Context;

import com.google.gson.Gson;
import com.ril.jioads.listeners.ProfileUpdateListener;
import com.ril.jioads.utils.AdsHelperUtils;
import com.ril.jioads.utils.ProfileManagingUtils;

import java.util.HashMap;

public class ProfileModel {
    ProfileUpdateListener profileUpdateListener;
    private Context context;
    private HashMap<String, String> profileMap;

    public ProfileModel(Context context, ProfileUpdateListener profileUpdateListener) {
        this.context = context;
        profileMap = new HashMap<>();
        this.profileUpdateListener = profileUpdateListener;
    }

    public ProfileModel add(String key, String... values) {
        if (AdsHelperUtils.isEmpty(key) || values == null || values.length == 0 || AdsHelperUtils.isEmpty(values[0])) {
            return this;
        }
        addValuesInProfile(key, values);
        return this;
    }

    private void addValuesInProfile(String key, String[] values) {
        String value = "";
        for (int i = 0; i < values.length; i++) {
            if (!AdsHelperUtils.isEmpty(values[i])) {
                value += values[i] + (i < (values.length - 1) ? "," : "");
            }
        }
        profileMap.put(key, value);
    }

    public boolean isEmpty() {
        if (profileMap != null && profileMap.keySet() != null && profileMap.keySet().size() > 0)
            return false;
        return true;
    }

    public HashMap<String, String> getProfileMap() {
        return profileMap;
    }

    public ProfileModel update() {
        save();
        if (profileUpdateListener != null)
            profileUpdateListener.profileUpdated(context);
        return this;
    }

    public void save() {
        String profileString = new Gson().toJson(profileMap);
        ProfileManagingUtils.saveProfile(context, profileString);
    }
}
