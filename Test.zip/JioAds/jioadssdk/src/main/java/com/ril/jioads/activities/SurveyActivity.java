package com.ril.jioads.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.ril.jio.jioads.R;

public class SurveyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.survey_main);
        setTempListener();
    }

    private void setTempListener() {
        findViewById(R.id.survey_send_feedback).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SurveyActivity.this, ThankYouActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

}
