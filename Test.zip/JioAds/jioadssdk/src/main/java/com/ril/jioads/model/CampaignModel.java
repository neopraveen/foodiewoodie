package com.ril.jioads.model;

/**
 * Created by ProBook on 8/2/2017.
 */

public class CampaignModel {
    public String CAMPAIGN_TITLE;
    public String STATUS;
    public String TRIGGER_TYPE;
    public String TRIGGERED_BY;
    public long CAMPAIGN_ID;
    public int MEDIASET_ID;
    public String SELECTED_DAYS;
    public String TRIGGER_NAME;
    public int MIN_CALL_DURATION;
    public String USERS_ROAMING;
    public String HEADER_TEXT;
    public String ADVERTISEMENT_TEXT;
    public String AD_FORMAT;
    public String REDIRECT_URL;
    public String OFFERTEXT;
    public String APPNAME;
    public String ADVERTISER;
    public String DELIVERY_TYPE;
    public String REMARK;
    public String PROFILE;
    public String CAMPAIGN_TYPE;
    public String PLATFORM;
    public String ADDINFO1;
    public String ADDINFO2;
    public String ADDINFO3;
    public String ADDINFO4;
    public String TITLE;
    public String LOGO_IMG_URL;
    public String BODY_IMG_URL;
    public String TXT_MSG;
    public String DEEP_LINK_URL;
    public String EXT_LINK_URL;
    public String FOOTER_MSG;


}
