package com.ril.jioads.model;

/**
 * Created by ProBook on 10/6/2017.
 */

public class UpdateProfileModel {
    String appName;
    String imei;
    String mobile;
    String circle;
    String mail;
    String customerId;
    String subscriberId;
    String customerType;
    String userType;
    String activationDate;
    String endPointUri;
    String userAuth;
    String userKey;
    String imsi;
    String type;
    String product;
    String operator;
    String reqFrom;
    String version;
}
