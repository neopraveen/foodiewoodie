package com.ril.jioads.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import com.ril.jioads.persistence.SharedPreferenceStore;
import com.ril.jioads.recievers.JioEventLoggerScheduleReceiver;

public class JioEventLoggerSchedulerUtils {
    public static final long LOG_UPDATE_INTERVAL = 2 * 60 * 60 * 1000;
    public static final int SCHEDULER_REQ_CODE = 8899;
    private static final String ALARM_START_TIMING = "alarm_s_timing";

    public static void checkAndScheduleLogUpdate(Context appContext) {
        if (!isSchedulerRunning(appContext)) {
            scheduleLogUpdate(appContext, System.currentTimeMillis() + LOG_UPDATE_INTERVAL);
        }
    }

    public static void checkAndScheduleLogUpdateOnReboot(Context appContext) {
        long lastSchedulerReceivedAt = SharedPreferenceStore.getValue(appContext, ALARM_START_TIMING, (long) 0);
        if (lastSchedulerReceivedAt > 0 && (System.currentTimeMillis() - lastSchedulerReceivedAt) < LOG_UPDATE_INTERVAL) {
            scheduleLogUpdate(appContext, System.currentTimeMillis() + LOG_UPDATE_INTERVAL);
        } else {
            scheduleLogUpdate(appContext, System.currentTimeMillis() + LOG_UPDATE_INTERVAL);
        }
    }

    public static void scheduleLogUpdate(Context appContext, long triggerAt) {
        Intent intent = new Intent(appContext, JioEventLoggerScheduleReceiver.class);
        PendingIntent pIntent = PendingIntent.getBroadcast(appContext, SCHEDULER_REQ_CODE, intent, 0);
        AlarmManager alarm = (AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
        alarm.setRepeating(AlarmManager.RTC_WAKEUP, triggerAt, LOG_UPDATE_INTERVAL, pIntent);
        setSchedulerRunning(appContext);
    }

    private static void setSchedulerRunning(Context appContext) {
        SharedPreferenceStore.storeValue(appContext, ALARM_START_TIMING, System.currentTimeMillis());
    }

    private static boolean isSchedulerRunning(Context appContext) {
        long lastSchedulerReceivedAt = SharedPreferenceStore.getValue(appContext, ALARM_START_TIMING, (long) 0);
        if (lastSchedulerReceivedAt > 0 && (System.currentTimeMillis() - lastSchedulerReceivedAt) < LOG_UPDATE_INTERVAL)
            return true;
        return false;
    }

    public static void setSchedulerReceived(Context applicationContext) {
        setSchedulerRunning(applicationContext);
    }
}
