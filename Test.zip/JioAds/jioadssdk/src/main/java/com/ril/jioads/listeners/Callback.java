package com.ril.jioads.listeners;

/**
 * Created by ProBook on 8/9/2017.
 */

public interface Callback {
    void onSuccess();

    void onFailure();
}
