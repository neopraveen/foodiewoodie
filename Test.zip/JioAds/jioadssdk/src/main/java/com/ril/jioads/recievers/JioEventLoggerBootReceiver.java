package com.ril.jioads.recievers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.ril.jioads.constants.Constants;
import com.ril.jioads.utils.JioEventLoggerSchedulerUtils;

public class JioEventLoggerBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        JioEventLoggerSchedulerUtils.checkAndScheduleLogUpdateOnReboot(context);
        Log.e(Constants.TAG, "BOOT COMPLETED");
    }
}
