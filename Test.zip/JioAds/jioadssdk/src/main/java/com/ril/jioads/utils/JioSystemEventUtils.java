package com.ril.jioads.utils;

import android.content.Context;

import com.ril.jioads.constants.AdType;

/**
 * Created by ProBook on 8/24/2017.
 */

public class JioSystemEventUtils {
    public static void onSMSReceived(Context context, String sender, String message) {
        if (JioAdsUtil.captureSystemEvents(context))
            JioAdsUtil.getInstance().showAds(context, AdType.AD_TYPE_SMS_IN, message);
    }

    public static void onChargerPluggedIn(Context context) {
        if (JioAdsUtil.captureSystemEvents(context))
            JioAdsUtil.getInstance().showAds(context, AdType.AD_TYPE_CHARGER_PLUGGED_IN);
    }

    public static void onChargerPluggedOut(Context context) {
        if (JioAdsUtil.captureSystemEvents(context))
            JioAdsUtil.getInstance().showAds(context, AdType.AD_TYPE_CHARGER_PLUGGED_OUT);
    }

    public static void onSystemReboot(Context context) {
        if (JioAdsUtil.captureSystemEvents(context))
            JioAdsUtil.getInstance().showAds(context, AdType.AD_TYPE_SYSTEM_REBOOT);
    }

    public static void onWifiLatched(Context context, String ssId) {
        if (JioAdsUtil.captureSystemEvents(context))
            JioAdsUtil.getInstance().showAds(context, AdType.AD_TYPE_WIFI_LATCHED, ssId);
    }

    public static void onEndCall(Context context, String caller) {
        if (JioAdsUtil.captureSystemEvents(context))
            JioAdsUtil.getInstance().showAds(context, AdType.AD_TYPE_END_OF_CALL);
    }

    public static void onAirplaneModeToggle(Context context, boolean airplaneModeStatus) {
        if (JioAdsUtil.captureSystemEvents(context))
            JioAdsUtil.getInstance().showAds(context, airplaneModeStatus ? AdType.AD_TYPE_AIRPLANE_MODE_ON : AdType.AD_TYPE_AIRPLANE_MODE_OFF);
    }

    public static void onDeviceUnlockScreen(Context context) {
        if (JioAdsUtil.captureSystemEvents(context))
            JioAdsUtil.getInstance().showAds(context, AdType.AD_TYPE_DEVICE_UNLOCKED);
    }

    public static void onRoaming(Context context) {
        if (JioAdsUtil.captureSystemEvents(context))
            JioAdsUtil.getInstance().showAds(context, AdType.AD_TYPE_ON_ROAMING);
    }
}
