package com.ril.jioads.rest;


import com.ril.jioads.model.ActiveCampaignResponseModel;
import com.ril.jioads.model.ConfigJioAds;
import com.ril.jioads.model.ConfigPostData;
import com.ril.jioads.model.EventLogResponseModel;
import com.ril.jioads.model.StandardRequestDataModel;
import com.ril.jioads.model.StandardResponseModel;
import com.ril.jioads.model.TokenResponseModel;
import com.ril.jioads.model.UpdateProfileModel;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiInterface {
    @POST("getToken")
    Call<TokenResponseModel> getToken(
            @Body StandardRequestDataModel dataModel
    );

    @POST("mobileuid/registerUser")
    Call<StandardResponseModel> registerUser(
            @Body StandardRequestDataModel standardRequestDataModel
    );

    @POST("mobileuid/updateprofiles")
    Call<StandardResponseModel> updateProfiles(
            @Body StandardRequestDataModel standardRequestDataModel
    );

    @POST("sendInAppEventsDetails")
    Call<EventLogResponseModel> logEvent(
            @Body StandardRequestDataModel dataModel
    );

    @POST("getConfiguration")
    Call<ConfigJioAds> logEvent(
            @Query("mobileUid") String mobileUid,
            @Query("endPointUri") String endPointUri,
            @Query("appName") String appName,
            @Query("imei") String imei,
            @Query("reqFrom") String reqFrom,
            @Body ConfigPostData configPostData
    );

    @POST("mobileuid/updateprofiledetails")
    Call<ResponseBody> updateProfile(
            @Query("mobileUid") String mobileUid,
            @Query("endPointUri") String endPointUri,
            @Query("appName") String appName,
            @Query("imei") String imei,
            @Query("reqFrom") String reqFrom,
            @Body UpdateProfileModel updateProfileModel
    );

    @POST("mobileuid/updateprofiledetails")
    Call<ResponseBody> updateUser(
            @Query("mobileUid") String mobileUid,
            @Query("endPointUri") String endPointUri,
            @Query("appName") String appName,
            @Query("imei") String imei,
            @Query("reqFrom") String reqFrom
    );

    @POST("getActiveCampaignDetails")
    Call<ActiveCampaignResponseModel> getActiveCampaignDetails(
            @Body StandardRequestDataModel standardRequestDataModel
    );

}
