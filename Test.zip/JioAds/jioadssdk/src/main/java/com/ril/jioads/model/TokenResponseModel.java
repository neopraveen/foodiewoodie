package com.ril.jioads.model;

/**
 * Created by ProBook on 1/4/2018.
 */

public class TokenResponseModel {
    public String token;
    public String status;
    public String statusDesc;
    public String configuration;
}
