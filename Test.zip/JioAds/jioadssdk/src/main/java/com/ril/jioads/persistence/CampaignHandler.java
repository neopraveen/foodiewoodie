package com.ril.jioads.persistence;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ril.jioads.constants.AdType;
import com.ril.jioads.model.AdsCampaignModel;
import com.ril.jioads.model.CampaignDetailsModel;
import com.ril.jioads.model.CampaignModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by ProBook on 8/8/2017.
 */

public class CampaignHandler {
    private static final String CAMPAIGN_LIST_SCN = "campaigns";

//    public static void saveCampaigns(Context context, List<CampaignDetailsModel> campaignDetailsModels) {
//        String campaignJson = new Gson().toJson(campaignDetailsModels);
//        SharedPreferenceStore.storeValue(context, CAMPAIGN_LIST_SCN, campaignJson);
//    }

    public static void saveCampaigns(Context context, List<AdsCampaignModel> campaignModels) {
        String campaignJson = new Gson().toJson(campaignModels);
        SharedPreferenceStore.storeValue(context, CAMPAIGN_LIST_SCN, campaignJson);
    }

    public static List<AdsCampaignModel> getAvailableCampaigns(Context context) {
        String campaignJson = SharedPreferenceStore.getValue(context, CAMPAIGN_LIST_SCN, "");
        if (campaignJson != null && !campaignJson.equals("")) {
            List<AdsCampaignModel> campaignDetailsModelList = new Gson().fromJson(campaignJson, new TypeToken<List<AdsCampaignModel>>() {
            }.getType());
            return campaignDetailsModelList;
        }
        return null;
    }

    public static void checkAndForceCacheImages(Context context, List<CampaignDetailsModel> campaignDetailsModelList) {
        for (int i = 0; i < campaignDetailsModelList.size(); i++) {
            if (campaignDetailsModelList.get(i).triggerType.equalsIgnoreCase(AdType.AD_TYPE_AIRPLANE_MODE_ON.adType)) {
                if (campaignDetailsModelList.get(i).mediaType != null && campaignDetailsModelList.get(i).mediaType.equalsIgnoreCase("image") && campaignDetailsModelList.get(i).mediasetUrl != null) {
                    Picasso.with(context).load(campaignDetailsModelList.get(i).mediasetUrl).fetch();
                }
            }
        }
    }
}
