package com.ril.jioads.listeners;

import android.content.Context;

public interface ProfileUpdateListener {
    void profileUpdated(Context context);
}
