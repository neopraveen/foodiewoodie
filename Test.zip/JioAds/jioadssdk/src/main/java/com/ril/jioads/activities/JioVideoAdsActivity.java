package com.ril.jioads.activities;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.VideoView;

import com.danikula.videocache.CacheListener;
import com.danikula.videocache.HttpProxyCacheServer;
import com.ril.jio.jioads.R;
import com.ril.jioads.constants.Constants;
import com.ril.jioads.model.AdsCampaignModel;
import com.ril.jioads.model.CampaignDetailsModel;
import com.ril.jioads.utils.JioAdsLoggingUtils;
import com.ril.jioads.utils.JioAdsTrackingUtils;
import com.ril.jioads.utils.JioAdsUtil;

import java.io.File;
import java.util.Date;

import static com.ril.jioads.persistence.DBAdapter.LOG_TAG;

/**
 * Created by ProBook on 8/10/2017.
 */

public class JioVideoAdsActivity extends AppCompatActivity implements CacheListener {
    VideoView jioVideoAdPlayer;
    AdsCampaignModel campaignDetailsModel;
    boolean infoNotLogged = true;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jiovideoads);
        jioVideoAdPlayer = (VideoView) findViewById(R.id.jio_video_ads_player);
        startVideo();
        initListener();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (infoNotLogged) {
            JioAdsTrackingUtils.getInstance().showingCampaign(getApplicationContext(), campaignDetailsModel);
//            JioAdsLoggingUtils.logEvent(Constants.ACTIVITY_TYPE_VIEW, new Date(), campaignDetailsModel, getApplicationContext());
            infoNotLogged = false;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            jioVideoAdPlayer.stopPlayback();
            JioAdsUtil.getProxy(this).unregisterCacheListener(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startVideo() {
        campaignDetailsModel = getIntent().getParcelableExtra(Constants.DATA);
        HttpProxyCacheServer proxy = JioAdsUtil.getProxy(this);
        proxy.registerCacheListener(this, campaignDetailsModel.mediasetUrl);
        String proxyUrl = proxy.getProxyUrl(campaignDetailsModel.mediasetUrl);
        Log.d(LOG_TAG, "Use proxy url " + proxyUrl + " instead of original url " + campaignDetailsModel.mediasetUrl);
        jioVideoAdPlayer.setVideoPath(proxyUrl);
        jioVideoAdPlayer.start();
        jioVideoAdPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                finish();
            }
        });
    }

    private void initListener() {
        findViewById(R.id.close_advertisement).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.jio_video_ads_player).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = campaignDetailsModel.redirectUrl;
                if (url != null) {
                    if (!url.startsWith("http://") && !url.startsWith("https://"))
                        url = "http://" + url;
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(browserIntent);
                    finish();
                }
//                JioAdsLoggingUtils.logEvent(Constants.ACTIVITY_TYPE_CLICK, new Date(), campaignDetailsModel, getApplicationContext());
            }
        });
    }

    @Override
    public void onCacheAvailable(File cacheFile, String url, int percentsAvailable) {

    }
}
