package com.ril.jioads.model;

/**
 * Created by ProBook on 1/9/2018.
 */

public class EventLoggerModel {
    public String campaingId;
    public double logTime;

}
