package com.ril.jioads.cryptoutils;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;


public class AesUtil {
    private static final int keySize = 128;
    private static final int iterationCount = 50;

    private static final String AES_TEXT = "AES/CBC/PKCS5Padding";//"AES/CBC/PKCS5Padding";
    private static final String secretKeyAlgorithm = "PBKDF2WithHmacSHA1";
    private static final String IV = "F27D5C9927726BCEFE7510B1BDD3D137";
    private static final String SALT = "3FF2EC019C627B945225DEBAD71A01B6985FE84C95A70EB132882F88C0A59A55";


    public static String encrypt(String token, String dataForEncryption) {
        return encrypt(SALT, IV, token, dataForEncryption);
    }

    public static String decrypt(String token, String dataForEncryption) {
        return decrypt(SALT, IV, token, dataForEncryption);
    }

    public static String encrypt(String salt, String iv, String passphrase, String plaintext) {
        try {
            SecretKey key = generateKey(salt, passphrase);
            byte[] encrypted = doFinal(Cipher.ENCRYPT_MODE, key, iv, plaintext.getBytes("UTF-8"));
            return base64(encrypted);
        } catch (UnsupportedEncodingException e) {
            throw fail(e);
        }
    }

    public static String decrypt(String salt, String iv, String passphrase, String ciphertext) {
        try {
            SecretKey key = generateKey(salt, passphrase);
            byte[] decrypted = doFinal(Cipher.DECRYPT_MODE, key, iv, base64(ciphertext));
            return new String(decrypted, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw fail(e);
        }
    }

    private static byte[] doFinal(int encryptMode, SecretKey key, String iv, byte[] bytes) {
        try {
            Cipher cipher = null;
            try {
                cipher = Cipher.getInstance(AES_TEXT);
                cipher.init(encryptMode, key, new IvParameterSpec(hex(iv)));
            } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            return cipher.doFinal(bytes);
        } catch (InvalidKeyException
                | InvalidAlgorithmParameterException
                | IllegalBlockSizeException
                | BadPaddingException e) {
            throw fail(e);
        }
    }

    private static SecretKey generateKey(String salt, String passphrase) {
        try {
            SecretKeyFactory factory = SecretKeyFactory.getInstance(secretKeyAlgorithm);
            KeySpec spec = new PBEKeySpec(passphrase.toCharArray(), hex(salt), iterationCount, keySize);
            SecretKey key = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
            return key;
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw fail(e);
        }
    }

    public static String random(int length) {
        byte[] salt = new byte[length];
        new SecureRandom().nextBytes(salt);
        return hex(salt);
    }

    public static String base64(byte[] bytes) {
        return new String(Base64.encodeBase64(bytes));
    }

    public static void main(String[] args) throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("uid", "1234567887654321");
        jsonObject.put("reqFrom", "Feature_Phone");
        jsonObject.put("version", "1.1.0");

        System.out.println(encrypt(SALT, IV, new StringBuilder("1234567887654321").reverse().toString(), "{\"uid\":\"1234567887654321\",\"reqFrom\":\"Feature_Phone\",\"version\":\"1.1.0\"}"));
        //decrypt(SALT, IV, new StringBuilder("1234567887654321").reverse().toString(), "zx5IFj2CPkJzc0O5Hrkwr4jnPwR4G47w1LvdYS0QxCu53aB3Faxvmb4Wdyil8wLg+9znCYlSynEYN/0anVXQts/ULVvaT8rqQJIU3Rs20wM=");
        //  	System.out.println(decrypt(SALT, IV, new StringBuilder("1234567887654321").reverse().toString(),encrypt(SALT, IV, new StringBuilder("1234567887654321").reverse().toString(),"Ajeet_Shukla")));

    }

    public static byte[] base64(String str) {
        return Base64.decodeBase64(str.getBytes());
    }

    public static String hex(byte[] bytes) {
        return Hex.encodeHexString(bytes);
    }

    public static byte[] hex(String str) {
        try {
            return Hex.decodeHex(str.toCharArray());
        } catch (DecoderException e) {
            throw new IllegalStateException(e);
        }
    }

    private static IllegalStateException fail(Exception e) {
        return new IllegalStateException(e);
    }

}
