package com.ril.jio.oseventlistner.services;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;

import com.ril.jio.oseventlistner.R;
import com.ril.jio.oseventlistner.call.JioPhoneStateListener;
import com.ril.jio.oseventlistner.interfaces.PhoneCallState;
import com.ril.jio.oseventlistner.model.EndCallData;
import com.ril.jio.oseventlistner.model.EndOfCallOnNumbersData;
import com.ril.jio.oseventlistner.model.RoamingData;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;

/**
 * Created by Administrator on 7/31/2017.
 */

public class OSEventListenerService extends Service implements PhoneCallState {


    private WindowManager.LayoutParams params1;
    private WindowManager wm;
    private LinearLayout ly1;

    @Override
    public void onCreate() {
        super.onCreate();
        EventBus.getDefault().register(this);

    }

    @Subscribe
    public void OnEvent(EndCallData endCallData) {
        listenEndOfCall();

    }

    @Subscribe
    public void OnEvent(EndOfCallOnNumbersData endOfCallOnNumbersData) {


    }

    @Subscribe
    public void OnEvent(RoamingData roamingData) {


    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        listenEndOfCall();
        return START_STICKY;

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    private void listenEndOfCall() {

        TelephonyManager tManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        tManager.listen(new JioPhoneStateListener(this, getApplicationContext()),
                PhoneStateListener.LISTEN_CALL_STATE);


    }

    private void listenEndOfCallOfNumbers(ArrayList<String> numbers) {

    }

    private void listenDeviceUnpluggedFromCharging() {

    }

    private void listenWIFILatching() {

    }

    private void listenWIFILatchingOnNames(ArrayList<String> names) {

    }

    private void listenDeviceReboot() {

    }

    private void listenAirplaneMode() {

    }

    private void listenDeviceUnlockScreen() {

    }

    private void listenSMS() {

    }

    private void listenRoaming() {

    }

    @Override
    public void onRinging(final String number, long start) {
        Log.e("OS", "onRinging");
//        new Handler().postDelayed(new Runnable() {
//
//            @Override
//            public void run() {
//              /*  EventData eventData = new EventData();
//                eventData.setName("End call");
//                eventData.setData(number);
//                Intent intent = new Intent(OSEventListenerService.this, JioBannerActivity.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
//                intent.putExtra("data", eventData);
//                startActivity(intent);*/
//
//                wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
//                params1 = new WindowManager.LayoutParams(
//                        WindowManager.LayoutParams.MATCH_PARENT,
//                        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_SYSTEM_ALERT |
//                        WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY,
//                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
//                                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
//                        PixelFormat.TRANSPARENT);
//
//      /*          params1.height = 75;
//                params1.width = 512;*/
//                params1.x = 0;
//                params1.y = 0;
//                params1.format = PixelFormat.TRANSLUCENT;
//
//                ly1 = new LinearLayout(OSEventListenerService.this);
//                ly1.setOrientation(LinearLayout.VERTICAL);
//                View hiddenInfo = LayoutInflater.from(getBaseContext()).inflate(R.layout.activity_jiobanner, ly1, false);
//                hiddenInfo.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        if (ly1 != null) {
//                            wm.removeView(ly1);
//                            ly1 = null;
//                        }
//                    }
//                });
//                ly1.addView(hiddenInfo);
////                wm.addView(ly1, params1);
//
//            }
//        }, 1000);


    }

    @Override
    public void onCallAnswer(String number, long start) {
       /* new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
              *//*  EventData eventData = new EventData();
                eventData.setName("End call");
                eventData.setData(number);
                Intent intent = new Intent(OSEventListenerService.this, JioBannerActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                intent.putExtra("data", eventData);
                startActivity(intent);*//*


                wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
                params1 = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_SYSTEM_ALERT |
                        WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                        PixelFormat.TRANSPARENT);

      *//*          params1.height = 75;
                params1.width = 512;*//*
                params1.x = 0;
                params1.y = 0;
                params1.format = PixelFormat.TRANSLUCENT;

                ly1 = new LinearLayout(OSEventListenerService.this);
                ly1.setOrientation(LinearLayout.VERTICAL);
                View hiddenInfo = LayoutInflater.from(getBaseContext()).inflate(R.layout.activity_jiobanner, ly1, false);
                hiddenInfo.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (ly1 != null) {
                            wm.removeView(ly1);
                            ly1 = null;
                        }
                    }
                });
                ly1.addView(hiddenInfo);
                wm.addView(ly1, params1);

            }
        }, 1000);*/

    }

    @Override
    public void onCallIDLE(String number, long start, long end) {
      /*  EventData eventData = new EventData();
        eventData.setName("End call");
        eventData.setData(number);
        Intent intent = new Intent(OSEventListenerService.this, BannerActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("data", eventData);
        startActivity(intent);*/

        if (ly1 != null) {
            wm.removeView(ly1);
            ly1 = null;
        }

    }


    @Override
    public void onOutgoingCallEnded(String number, long start, long end) {


    }

    @Override
    public void onMissedCall(String number, long start) {

    }
}
