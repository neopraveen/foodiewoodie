package com.ril.jio.oseventlistner.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.ril.jioads.utils.JioSystemEventUtils;

/**
 * Created by Administrator on 8/1/2017.
 */

public class ConnectivityReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        boolean isPlaneModeOn = intent.getBooleanExtra("state", false);
        JioSystemEventUtils.onAirplaneModeToggle(context, isPlaneModeOn);
//        EventData eventData = new EventData();
//        eventData.setName("Airplane mode");
//        eventData.setData(isPlaneModeOn ? "ON" : "OFF");
//        Intent rootIntent = new Intent(context, BannerActivity.class);
//        rootIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        rootIntent.putExtra("data", eventData);
//        context.startActivity(rootIntent);
    }
}
