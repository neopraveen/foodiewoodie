package com.ril.jio.oseventlistner.model;

/**
 * Created by Administrator on 7/31/2017.
 */

public class RoamingData {
    private boolean isListen;

    public boolean isListen() {
        return isListen;
    }

    public void setListen(boolean listen) {
        isListen = listen;
    }
}
