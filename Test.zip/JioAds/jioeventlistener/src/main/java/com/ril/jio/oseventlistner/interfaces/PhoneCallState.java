package com.ril.jio.oseventlistner.interfaces;

/**
 * Created by Administrator on 7/31/2017.
 */

public interface PhoneCallState {

    void onRinging(String number, long start);

    void onCallAnswer(String number, long start);

    void onCallIDLE(String number, long start, long end);

    void onOutgoingCallEnded(String number, long start, long end);

    void onMissedCall(String number, long start);
}
