package com.ril.jio.oseventlistner.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.ril.jioads.utils.JioSystemEventUtils;


public class BootReceiver extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        JioSystemEventUtils.onSystemReboot(context);
//        EventData eventData = new EventData();
//        eventData.setName("Device reboot");
//        eventData.setData("");
//        Intent rootIntent = new Intent(context, BannerActivity.class);
//        rootIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        rootIntent.putExtra("data", eventData);
//        context.startActivity(rootIntent);
    }
}
