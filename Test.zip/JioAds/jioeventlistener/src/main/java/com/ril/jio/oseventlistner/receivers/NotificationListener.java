package com.ril.jio.oseventlistner.receivers;

import android.app.Notification;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.support.annotation.RequiresApi;
import android.util.Log;

/**
 * Created by Administrator on 8/2/2017.
 */

@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
public class NotificationListener extends NotificationListenerService {
    private String TAG = this.getClass().getSimpleName();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        Log.i(TAG, "Notification Posted");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {


            Bundle extras = sbn.getNotification().extras;
            if ("Ongoing call".equals(extras.getString(Notification.EXTRA_TEXT))){

            }
            else if ("Dialing".equals(extras.getString(Notification.EXTRA_TEXT))){

            }

        }


    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        Log.i(TAG, "********** onNotificationRemoved");
        Log.i(TAG, "ID :" + sbn.getId() + "\t" + sbn.getNotification().tickerText + "\t" + sbn.getPackageName());
    }
}