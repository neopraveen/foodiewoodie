package com.ril.jio.oseventlistner.model;

import java.util.ArrayList;

/**
 * Created by Administrator on 7/31/2017.
 */

public class EndOfCallOnNumbersData {

    private ArrayList<String> numbers;
    private boolean isListen;

    public boolean isListen() {
        return isListen;
    }

    public void setListen(boolean listen) {
        isListen = listen;
    }

    public ArrayList<String> getNumbers() {
        return numbers;
    }

    public void setNumbers(ArrayList<String> numbers) {
        this.numbers = numbers;
    }
}
