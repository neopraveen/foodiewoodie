package com.ril.jio.oseventlistner.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import com.ril.jioads.utils.JioSystemEventUtils;

/**
 * Created by Administrator on 8/1/2017.
 */

public class IncomingSms extends BroadcastReceiver {
    public static final String SMS_BUNDLE = "pdus";

    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle intentExtras = intent.getExtras();
        if (intentExtras != null) {
            Object[] sms = (Object[]) intentExtras.get(SMS_BUNDLE);
            String smsMessageStr = "";

            try {
                for (int i = 0; i < sms.length; ++i) {
                    SmsMessage smsMessage = null;
                    if (Build.VERSION.SDK_INT >= 19) { //KITKAT
                        SmsMessage[] msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent);
                        smsMessage = msgs[0];
                    } else {
                        smsMessage = SmsMessage
                                .createFromPdu((byte[]) sms[i]);
                    }

                    if (smsMessage != null) {
                        String phoneNumber = smsMessage.getDisplayOriginatingAddress();
                        String message = smsMessage.getDisplayMessageBody();
                        JioSystemEventUtils.onSMSReceived(context, phoneNumber, message);
//                        JioSystemEventUtils
//                        EventData eventData = new EventData();
//                        eventData.setName("SMS received");
//                        eventData.setData(phoneNumber + "\n" + message);
//                        Intent smsIntent = new Intent(context, BannerActivity.class);
//                        smsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                        smsIntent.putExtra("data", eventData);
//                        context.startActivity(smsIntent);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }
}