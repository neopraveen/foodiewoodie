package com.ril.jio.oseventlistner.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.ril.jio.oseventlistner.activity.BannerActivity;
import com.ril.jio.oseventlistner.model.EventData;
import com.ril.jioads.utils.JioSystemEventUtils;

/**
 * Created by Administrator on 8/1/2017.
 */

public class PlugInControlReceiver extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action.equals(Intent.ACTION_POWER_CONNECTED)) {
            JioSystemEventUtils.onChargerPluggedIn(context);
//            EventData eventData = new EventData();
//            eventData.setName("Device plugged for charging");
//            eventData.setData("");
//            Intent rootIntent = new Intent(context, BannerActivity.class);
//            rootIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            rootIntent.putExtra("data", eventData);
//            context.startActivity(rootIntent);
        } else if (action.equals(Intent.ACTION_POWER_DISCONNECTED)) {
            JioSystemEventUtils.onChargerPluggedOut(context);
//            EventData eventData = new EventData();
//            eventData.setName("Device unplugged from charging");
//            eventData.setData("");
//            Intent rootIntent = new Intent(context, BannerActivity.class);
//            rootIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            rootIntent.putExtra("data", eventData);
//            context.startActivity(rootIntent);
        }
    }
}