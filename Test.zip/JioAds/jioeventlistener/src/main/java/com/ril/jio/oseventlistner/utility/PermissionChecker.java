package com.ril.jio.oseventlistner.utility;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;


public class PermissionChecker {


    public static final int MY_PERMISSIONS_REQUEST = 1002;


    public static boolean checkReadPhoneStatePermission(final Activity activity) {
        if (ContextCompat.checkSelfPermission(activity,
                Manifest.permission.RECEIVE_BOOT_COMPLETED)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(activity,
                Manifest.permission.SYSTEM_ALERT_WINDOW)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(activity,
                Manifest.permission.VIBRATE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(activity,
                Manifest.permission.CHANGE_WIFI_MULTICAST_STATE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(activity,
                Manifest.permission.CHANGE_WIFI_STATE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(activity,
                Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(activity,
                Manifest.permission.ACCESS_WIFI_STATE)
                != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(activity,
                        Manifest.permission.READ_SMS)
                        != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(activity,
                Manifest.permission.RECEIVE_SMS)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(activity,
                Manifest.permission.MODIFY_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    Manifest.permission.READ_SMS) || ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    Manifest.permission.RECEIVE_SMS) || ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    Manifest.permission.ACCESS_WIFI_STATE) || ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    Manifest.permission.CHANGE_WIFI_MULTICAST_STATE) || ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    Manifest.permission.CHANGE_WIFI_STATE) || ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    Manifest.permission.READ_PHONE_STATE) || ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    Manifest.permission.RECEIVE_BOOT_COMPLETED) || ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    Manifest.permission.VIBRATE) || ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    Manifest.permission.SYSTEM_ALERT_WINDOW) || ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    Manifest.permission.MODIFY_PHONE_STATE)) {

                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                AlertDialog.Builder alertBuilder = new AlertDialog.Builder(activity);
                alertBuilder.setCancelable(true);
                alertBuilder.setTitle("Permissions are necessary");
                alertBuilder.setMessage("Below permissions are necessary to run the app");
                alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ActivityCompat.requestPermissions(activity, new String[]{
                                Manifest.permission.VIBRATE,
                                Manifest.permission.READ_PHONE_STATE,
                                Manifest.permission.ACCESS_WIFI_STATE, Manifest.permission.CHANGE_WIFI_MULTICAST_STATE, Manifest.permission.CHANGE_WIFI_STATE, Manifest.permission.RECEIVE_BOOT_COMPLETED,
                                Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.SYSTEM_ALERT_WINDOW, Manifest.permission.MODIFY_PHONE_STATE}, MY_PERMISSIONS_REQUEST);

                    }
                });

                AlertDialog alert = alertBuilder.create();
                alert.show();


            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(activity,
                        new String[]{
                                Manifest.permission.VIBRATE,
                                Manifest.permission.READ_PHONE_STATE,
                                Manifest.permission.ACCESS_WIFI_STATE, Manifest.permission.CHANGE_WIFI_MULTICAST_STATE, Manifest.permission.CHANGE_WIFI_STATE, Manifest.permission.RECEIVE_BOOT_COMPLETED,
                                Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.SYSTEM_ALERT_WINDOW, Manifest.permission.MODIFY_PHONE_STATE},
                        MY_PERMISSIONS_REQUEST);


            }
            return false;
        }
        return true;
    }


}
