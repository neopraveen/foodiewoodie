package com.ril.jio.oseventlistner.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;

import com.ril.jio.oseventlistner.activity.BannerActivity;
import com.ril.jio.oseventlistner.model.EventData;
import com.ril.jioads.utils.JioSystemEventUtils;

/**
 * Created by Administrator on 8/1/2017.
 */

public class ConnectivityChangedReceiver extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        TelephonyManager tManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (tManager.isNetworkRoaming()) {
            JioSystemEventUtils.onRoaming(context);
//            EventData eventData = new EventData();
//            eventData.setName("On Roaming");
//            eventData.setData("");
//            Intent roamingIntent = new Intent(context, BannerActivity.class);
//            roamingIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            roamingIntent.putExtra("data", eventData);
//            context.startActivity(roamingIntent);
        }

    }
}
