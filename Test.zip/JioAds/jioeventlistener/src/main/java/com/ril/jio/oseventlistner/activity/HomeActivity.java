package com.ril.jio.oseventlistner.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SwitchCompat;

import com.ril.jio.oseventlistner.R;
import com.ril.jio.oseventlistner.services.OSEventListenerService;
import com.ril.jio.oseventlistner.utility.PermissionChecker;
import com.ril.jio.oseventlistner.utility.PreferenceHelper;

/**
 * Created by Administrator on 7/31/2017.
 */

public class HomeActivity extends AppCompatActivity {

    private SwitchCompat endCall;
    private SwitchCompat endCallOnCall;
    private SwitchCompat deviceUnPluggedFromCharging;
    private SwitchCompat wifiLatching;
    private SwitchCompat wifiLatchingOnName;
    private SwitchCompat deviceReboot;
    private SwitchCompat airplaneMode;
    private SwitchCompat deviceUnlockScreen;
    private SwitchCompat sms;
    private SwitchCompat roaming;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        PermissionChecker.checkReadPhoneStatePermission(this);
        initUI();
    }

    private void initUI() {
        endCall = (SwitchCompat) findViewById(R.id.end_of_call);
        endCallOnCall = (SwitchCompat) findViewById(R.id.end_of_call_on_specific_number);
        deviceUnPluggedFromCharging = (SwitchCompat) findViewById(R.id.unplugged_from_charging);
        wifiLatching = (SwitchCompat) findViewById(R.id.wifi_latching);
        wifiLatchingOnName = (SwitchCompat) findViewById(R.id.wifi_latching_to_a_named_wifi);
        deviceReboot = (SwitchCompat) findViewById(R.id.device_reboot);
        airplaneMode = (SwitchCompat) findViewById(R.id.airplane_mode);
        deviceUnlockScreen = (SwitchCompat) findViewById(R.id.device_unlock_screen);
        sms = (SwitchCompat) findViewById(R.id.sms);
        roaming = (SwitchCompat) findViewById(R.id.on_roaming);

        PreferenceHelper preferenceHelper = PreferenceHelper.getPreferenceHelperInstance();

        endCall.setChecked(preferenceHelper.getBooleanPreference(getApplicationContext(), PreferenceHelper.Key.END_CALL));
        endCallOnCall.setChecked(preferenceHelper.getBooleanPreference(getApplicationContext(), PreferenceHelper.Key.END_CALL_TO_A_SPECIFIC_NUMBER));
        deviceUnPluggedFromCharging.setChecked(preferenceHelper.getBooleanPreference(getApplicationContext(), PreferenceHelper.Key.DEVICE_UNPLUGGED_FROM_CHARGING));
        wifiLatching.setChecked(preferenceHelper.getBooleanPreference(getApplicationContext(), PreferenceHelper.Key.WIFI_LATCHING));
        wifiLatchingOnName.setChecked(preferenceHelper.getBooleanPreference(getApplicationContext(), PreferenceHelper.Key.WIFI_LATCHING_TO_A_NAME));
        deviceReboot.setChecked(preferenceHelper.getBooleanPreference(getApplicationContext(), PreferenceHelper.Key.DEVICE_REBOOT));
        airplaneMode.setChecked(preferenceHelper.getBooleanPreference(getApplicationContext(), PreferenceHelper.Key.AIRPLANE_MODE));
        deviceUnlockScreen.setChecked(preferenceHelper.getBooleanPreference(getApplicationContext(), PreferenceHelper.Key.DEVICE_UNLOOK_SCREEN));
        sms.setChecked(preferenceHelper.getBooleanPreference(getApplicationContext(), PreferenceHelper.Key.SMS));
        roaming.setChecked(preferenceHelper.getBooleanPreference(getApplicationContext(), PreferenceHelper.Key.ROAMING));

        startOSEventListenerService();
    }

    private void startOSEventListenerService() {
        Intent intent = new Intent(HomeActivity.this, OSEventListenerService.class);
        startService(intent);
    }


    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();
        savePrefences();
    }

    private void savePrefences() {
        PreferenceHelper preferenceHelper = PreferenceHelper.getPreferenceHelperInstance();
        preferenceHelper.saveBooleanPreference(getApplicationContext(), PreferenceHelper.Key.END_CALL, endCall.isChecked());
        preferenceHelper.saveBooleanPreference(getApplicationContext(), PreferenceHelper.Key.END_CALL_TO_A_SPECIFIC_NUMBER, endCallOnCall.isChecked());
        preferenceHelper.saveBooleanPreference(getApplicationContext(), PreferenceHelper.Key.DEVICE_UNPLUGGED_FROM_CHARGING, deviceUnPluggedFromCharging.isChecked());
        preferenceHelper.saveBooleanPreference(getApplicationContext(), PreferenceHelper.Key.WIFI_LATCHING, wifiLatching.isChecked());
        preferenceHelper.saveBooleanPreference(getApplicationContext(), PreferenceHelper.Key.WIFI_LATCHING_TO_A_NAME, wifiLatchingOnName.isChecked());
        preferenceHelper.saveBooleanPreference(getApplicationContext(), PreferenceHelper.Key.DEVICE_REBOOT, deviceReboot.isChecked());
        preferenceHelper.saveBooleanPreference(getApplicationContext(), PreferenceHelper.Key.AIRPLANE_MODE, airplaneMode.isChecked());
        preferenceHelper.saveBooleanPreference(getApplicationContext(), PreferenceHelper.Key.DEVICE_UNLOOK_SCREEN, deviceUnlockScreen.isChecked());
        preferenceHelper.saveBooleanPreference(getApplicationContext(), PreferenceHelper.Key.SMS, sms.isChecked());
        preferenceHelper.saveBooleanPreference(getApplicationContext(), PreferenceHelper.Key.ROAMING, roaming.isChecked());
    }
}
