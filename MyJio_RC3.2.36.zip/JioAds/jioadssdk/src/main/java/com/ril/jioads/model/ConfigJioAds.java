package com.ril.jioads.model;

/**
 * Created by ProBook on 10/5/2017.
 */

public class ConfigJioAds {
    public String status;
    public String statusDesc;
    public boolean appflag;
    public String base_url;
    public int reattemtCount;
    public int reattemptIntervalInMin;
    public int scheduleIntervalInMin;
    public ConfigAdsSetting getAd;
    public ConfigAdsSetting updateProfile;
}
