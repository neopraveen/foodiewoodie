package com.ril.jioads.model;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

public class NotificationModel implements Parcelable{
    public static final int MEDIA_TYPE_TEXT = 0;
    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int ACTION_TYPE_IS_SILENT = 0;
    public static final int ACTION_TYPE_EXTERNAL_LINK = 1;
    public static final int ACTION_TYPE_DEEP_LINK = 2;

    public String campaingId;
    public String title;
    public String message;
    public String iconUrl;
    public String imgUrl;
    public String deeplink;
    public int mediaType;        // (0 - text, 1 - image)
    public int actionType;       //(0 - is silent, 1 - External Link (Open in browser), 2 - InApp DeepLink)
    public Bitmap iconBitmap;
    public Bitmap imgBitmap;

    protected NotificationModel(Parcel in) {
        campaingId = in.readString();
        title = in.readString();
        message = in.readString();
        iconUrl = in.readString();
        imgUrl = in.readString();
        deeplink = in.readString();
        mediaType = in.readInt();
        actionType = in.readInt();
        iconBitmap = in.readParcelable(Bitmap.class.getClassLoader());
        imgBitmap = in.readParcelable(Bitmap.class.getClassLoader());
    }

    public static final Creator<NotificationModel> CREATOR = new Creator<NotificationModel>() {
        @Override
        public NotificationModel createFromParcel(Parcel in) {
            return new NotificationModel(in);
        }

        @Override
        public NotificationModel[] newArray(int size) {
            return new NotificationModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(campaingId);
        dest.writeString(title);
        dest.writeString(message);
        dest.writeString(iconUrl);
        dest.writeString(imgUrl);
        dest.writeString(deeplink);
        dest.writeInt(mediaType);
        dest.writeInt(actionType);
        dest.writeParcelable(iconBitmap, flags);
        dest.writeParcelable(imgBitmap, flags);
    }
}
