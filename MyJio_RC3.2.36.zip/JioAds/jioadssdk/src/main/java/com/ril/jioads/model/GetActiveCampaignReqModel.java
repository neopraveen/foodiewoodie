package com.ril.jioads.model;

/**
 * Created by ProBook on 1/4/2018.
 */

public class GetActiveCampaignReqModel {
    public String imei;
    public String version;
    public String reqFrom;
    public String appName;

    public GetActiveCampaignReqModel(String imei, String version, String reqFrom, String appName) {
        this.imei = imei;
        this.version = version;
        this.reqFrom = reqFrom;
        this.appName = appName;
    }
}
