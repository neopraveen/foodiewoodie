package com.ril.jioads.utils;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;

import com.google.gson.Gson;
import com.ril.jioads.constants.Constants;
import com.ril.jioads.model.ConfigurationModel;
import com.ril.jioads.persistence.SharedPreferenceStore;

import java.util.Random;
import java.util.UUID;

/**
 * Created by ProBook on 8/7/2017.
 */

public class AdsHelperUtils {
    public static String getApplicationName(Context context) {
        try {
            return JioAdsUtil.getInstance().getLastSavedUserDetails(context).getAppName();
//            ApplicationInfo applicationInfo = context.getApplicationInfo();
//            int stringId = applicationInfo.labelRes;
//            return stringId == 0 ? applicationInfo.nonLocalizedLabel.toString() : context.getString(stringId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "MyJio";
    }

    public static String getAppVersion(Context context) {
        try {
            return JioAdsUtil.getInstance().getLastSavedUserDetails(context).getAppVersion();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "1.1.0";
    }

    public static void saveConfiguration(Context context, ConfigurationModel configurationModel) {
        String configurationString = new Gson().toJson(configurationModel);
        SharedPreferenceStore.storeValue(context, Constants.ADS_COFIG_SCN, configurationString);
    }


    public static ConfigurationModel getConfiguration(Context context) {
        String configString = SharedPreferenceStore.getValue(context, Constants.ADS_COFIG_SCN, "");
        if (configString != null && !configString.equals("")) {
            return new Gson().fromJson(configString, ConfigurationModel.class);
        }
        return null;
    }

    public static void saveToken(Context context, String token) {
        SharedPreferenceStore.storeValue(context, Constants.ADS_TOKEN_SCN, token);
    }

    public static void resetToken(Context context) {
        SharedPreferenceStore.deleteValue(context, Constants.ADS_TOKEN_SCN);
    }

    public static String getToken(Context context) {
        return SharedPreferenceStore.getValue(context, Constants.ADS_TOKEN_SCN, "");
    }

    public static String generateUUID(Context context, boolean forceGenerate) {
        String uuid = SharedPreferenceStore.getValue(context, Constants.ADS_UUID_SCN, "");
        if (forceGenerate || uuid.equals("")) {
            uuid = UUID.randomUUID().toString();
            SharedPreferenceStore.storeValue(context, Constants.ADS_UUID_SCN, uuid);
        }
        return uuid;
    }

    public static String getMobileUid(Context context) {
        String mobileUID = SharedPreferenceStore.getValue(context, Constants.ADS_MOBILE_UID_SCN, "");
        if (mobileUID.equals("")) {
            mobileUID = getApplicationName(context).substring(0, 4) + get4DigitRandomNumber() + get4DigitRandomNumber() + get4DigitRandomNumber() + get3DigitRandomNumber();
            SharedPreferenceStore.storeValue(context, Constants.ADS_MOBILE_UID_SCN, mobileUID);
        }
        return mobileUID;
    }

    public static String get4DigitRandomNumber() {
        Random random = new Random();
        int randInt = 10000 + random.nextInt(89999);
        return String.valueOf(randInt).substring(1);
    }

    public static String get3DigitRandomNumber() {
        Random random = new Random();
        int randInt = 10000 + random.nextInt(89999);
        return String.valueOf(randInt).substring(2);
    }

//    public static String getIMEIId(Context context) {
//        try {
//            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
//            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
//                return "";
//            }
//            return telephonyManager.getDeviceId();
//        } catch (Exception e) {
//            e.printStackTrace();
//            return "Invalid IMEI";
//        }
//    }

    public static boolean isRegistrationDone(Context context) {
        return SharedPreferenceStore.getValue(context, Constants.REGISTRATION_SCN, false);
    }

    public static void clientRegisteredSuccessfully(Context context) {
        SharedPreferenceStore.storeValue(context, Constants.REGISTRATION_SCN, true);
    }

    public static boolean isEmpty(String text) {
        if (text != null && !text.equals(""))
            return false;
        return true;
    }
}
