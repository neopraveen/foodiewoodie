package com.ril.jioads.model;

/**
 * Created by ProBook on 1/4/2018.
 */

public class RegisterUserResponseModel {
    public String data;
    public String status;
    public String statusDesc;

}
