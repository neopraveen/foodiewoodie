package com.ril.jioads.constants;

/**
 * Created by ProBook on 8/2/2017.
 */

public enum AdType {
    AD_TYPE_MY_PLANS("Myplans"), AD_TYPE_LAUNCH_APP("launchapp"), AD_TYPE_RECHARGE("Recharge"),
    AD_TYPE_MY_BILL("My bill"),
    AD_TYPE_MY_USAGE("My usage"),
    AD_TYPE_PAYMENT_HISTORY("Payment history"),
    AD_TYPE_DASHBOARD("Dashboard"),
    AD_TYPE_STATEMENT("Statement"),
    AD_TYPE_MY_ACCOUNT("My account"),
    AD_TYPE_MY_SETTING("My setting"),
    AD_TYPE_JIO_CARE("Jio care"),
    AD_TYPE_END_OF_CALL("OnEndCall"), AD_TYPE_SMS_IN("SmsIn"), AD_TYPE_CHARGER_PLUGGED_IN("ChargerPluggedIn"), AD_TYPE_CHARGER_PLUGGED_OUT("ChargerPluggedOut"), AD_TYPE_SYSTEM_REBOOT("SystemReboot"), AD_TYPE_WIFI_LATCHED("WifiLatched"), AD_TYPE_ON_END_CALL("OnEndCall"), AD_TYPE_AIRPLANE_MODE_ON("AirplaneModeOn"), AD_TYPE_AIRPLANE_MODE_OFF("AirplaneModeOff"), AD_TYPE_DEVICE_UNLOCKED("DeviceUnlocked"), AD_TYPE_ON_ROAMING("OnRoaming");
    public String adType;

    AdType(String adType) {
        this.adType = adType;
    }
}
