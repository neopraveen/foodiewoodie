package com.ril.jioads.firebase.service;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.ril.jioads.constants.Constants;
import com.ril.jioads.persistence.SharedPreferenceStore;
import com.ril.jioads.utils.JioAdsUtil;


/**
 * Created by Ravi Tamada on 08/08/16.
 * www.androidhive.info
 */
public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {
    private static final String TAG = "FCM";

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        // Saving reg id to shared preferences
//        storeRegIdInPref(refreshedToken);
        JioAdsUtil.pt("Firebase Token");
        JioAdsUtil.pl(refreshedToken);
        // sending reg id to your server
        sendRegistrationToServer(refreshedToken);
    }

    private void sendRegistrationToServer(final String token) {
        // sending gcm token to server
        JioAdsUtil.getInstance().updateFireBaseToken(getApplicationContext(), token);
        Log.e(TAG, "sendRegistrationToServer: " + token);
    }

    private void storeRegIdInPref(String token) {
        SharedPreferenceStore.storeValue(getApplicationContext(), Constants.FB_TOKEN, token);
        Log.e(TAG, "sendRegistrationToServer: " + token);
    }
}

