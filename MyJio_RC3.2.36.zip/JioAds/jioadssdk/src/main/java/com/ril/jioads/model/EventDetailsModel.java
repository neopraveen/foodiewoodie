package com.ril.jioads.model;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by ProBook on 8/31/2017.
 */

public class EventDetailsModel {
    public String imei;
    public String appName;
    public List<CapturedInAppEventsModel> capturedInAppEvents;

    public void setCapturedInAppEvents(String activity, AdsCampaignModel campaignDetailsModel, Date eventDate) {
        CapturedInAppEventsModel capturedInAppEventsModel = new CapturedInAppEventsModel();
        capturedInAppEventsModel.activity = activity;
        capturedInAppEventsModel.campaignID = campaignDetailsModel.campaignId;
        capturedInAppEventsModel.campaignName = campaignDetailsModel.campaignTitle;
        capturedInAppEventsModel.triggerType = campaignDetailsModel.triggerType;
        capturedInAppEventsModel.setEventTime(eventDate);
        capturedInAppEvents = new ArrayList<>();
        capturedInAppEvents.add(capturedInAppEventsModel);
    }


    public void setCapturedInAppEvents(String activity, List<CampaignDetailsModel> campaignDetailsModels, Date eventDate) {
        capturedInAppEvents = new ArrayList<>();
        for (CampaignDetailsModel campaignDetailsModel : campaignDetailsModels) {
            CapturedInAppEventsModel capturedInAppEventsModel = new CapturedInAppEventsModel();
            capturedInAppEventsModel.activity = activity;
            capturedInAppEventsModel.campaignID = campaignDetailsModel.campaignId;
            capturedInAppEventsModel.campaignName = campaignDetailsModel.campaignTitle;
            capturedInAppEventsModel.triggerType = campaignDetailsModel.triggerType;
            capturedInAppEventsModel.setEventTime(eventDate);
            capturedInAppEvents.add(capturedInAppEventsModel);
        }
    }


    public String getCapturedInAppEvents() {
        return new Gson().toJson(capturedInAppEvents);
    }
}
