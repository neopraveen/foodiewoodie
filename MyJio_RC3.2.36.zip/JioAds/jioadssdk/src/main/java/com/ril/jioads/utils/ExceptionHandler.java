package com.ril.jioads.utils;

/**
 * Created by ProBook on 10/5/2017.
 */

public class ExceptionHandler {
    public static void handle(Exception e){
        e.printStackTrace();
    }
}
