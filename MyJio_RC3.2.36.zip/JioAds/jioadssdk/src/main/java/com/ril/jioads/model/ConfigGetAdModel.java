package com.ril.jioads.model;

/**
 * Created by ProBook on 1/4/2018.
 */

public class ConfigGetAdModel {
    public boolean flag;
    public int reattemtCount;
    public int reattemptIntervalInMin;
    public int scheduleIntervalInMin;
    public String dayWise;
    public int dayIntervals;
}
