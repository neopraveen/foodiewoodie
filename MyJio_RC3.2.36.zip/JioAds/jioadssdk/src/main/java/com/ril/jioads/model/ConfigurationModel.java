package com.ril.jioads.model;

/**
 * Created by ProBook on 1/4/2018.
 */

public class ConfigurationModel {
    public String status;
    public String statusDesc;
    public boolean appflag;
    public boolean isCmapaignSchedularEnable;
    public String base_url;
    public int reattemtCount;
    public int reattemptIntervalInMin;
    public int scheduleIntervalInMin;
    public ConfigGetAdModel getAd;
    public ConfigUpdateProfileModel updateProfile;
}
