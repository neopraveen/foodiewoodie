package com.ril.jioads.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by ProBook on 1/9/2018.
 */

public class AdsCampaignScheduleModel implements Parcelable {
    public static final Creator<AdsCampaignScheduleModel> CREATOR = new Creator<AdsCampaignScheduleModel>() {
        @Override
        public AdsCampaignScheduleModel createFromParcel(Parcel in) {
            return new AdsCampaignScheduleModel(in);
        }

        @Override
        public AdsCampaignScheduleModel[] newArray(int size) {
            return new AdsCampaignScheduleModel[size];
        }
    };
    public String scheduledtype;
    public String campaignFrequency;
    public String recurringDate;
    public ScheduleCampaignTimeModel[] scheduleCampaignTime;

    protected AdsCampaignScheduleModel(Parcel in) {
        scheduledtype = in.readString();
        campaignFrequency = in.readString();
        recurringDate = in.readString();
        scheduleCampaignTime = in.createTypedArray(ScheduleCampaignTimeModel.CREATOR);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(scheduledtype);
        dest.writeString(campaignFrequency);
        dest.writeString(recurringDate);
        dest.writeTypedArray(scheduleCampaignTime, flags);
    }

    public static class ScheduleCampaignTimeModel implements Parcelable {
        public static final Creator<ScheduleCampaignTimeModel> CREATOR = new Creator<ScheduleCampaignTimeModel>() {
            @Override
            public ScheduleCampaignTimeModel createFromParcel(Parcel in) {
                return new ScheduleCampaignTimeModel(in);
            }

            @Override
            public ScheduleCampaignTimeModel[] newArray(int size) {
                return new ScheduleCampaignTimeModel[size];
            }
        };
        public int id;
        public String starttime;
        public String endtime;
        public String startdate;
        public String enddate;
        public String recurringDate;

        protected ScheduleCampaignTimeModel(Parcel in) {
            id = in.readInt();
            starttime = in.readString();
            endtime = in.readString();
            startdate = in.readString();
            enddate = in.readString();
            recurringDate = in.readString();
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(id);
            dest.writeString(starttime);
            dest.writeString(endtime);
            dest.writeString(startdate);
            dest.writeString(enddate);
            dest.writeString(recurringDate);
        }
    }
}
