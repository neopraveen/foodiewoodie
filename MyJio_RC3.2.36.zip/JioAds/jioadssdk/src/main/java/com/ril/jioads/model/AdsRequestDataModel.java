package com.ril.jioads.model;

public class AdsRequestDataModel {
    public String uid;
    public String data;
}