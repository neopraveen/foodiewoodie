package com.ril.jioads.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import com.ril.jio.jioads.R;
import com.ril.jioads.constants.AdType;
import com.ril.jioads.constants.Constants;
import com.ril.jioads.model.AdsCampaignModel;
import com.ril.jioads.utils.JioAdsLoggingUtils;
import com.ril.jioads.utils.JioAdsTrackingUtils;
import com.ril.jioads.utils.JioAdsUtil;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.Date;

/**
 * Created by ProBook on 8/8/2017.
 */

public class JioImageAdsActivity extends AppCompatActivity {
    AdsCampaignModel campaignDetailsModel;
    boolean infoNotLogged = true;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jioads);
        loadAdvertisementImage();
        initListener();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (infoNotLogged) {
            JioAdsTrackingUtils.getInstance().showingCampaign(getApplicationContext(), campaignDetailsModel);
            JioAdsLoggingUtils.logEvent(Constants.ACTIVITY_TYPE_VIEW, new Date(), campaignDetailsModel, getApplicationContext());
            infoNotLogged = false;
        }
    }

    private void loadAdvertisementImage() {
        campaignDetailsModel = getIntent().getParcelableExtra(Constants.DATA);
        if (campaignDetailsModel != null) {
            String imageUrl = campaignDetailsModel.mediasetUrl;
            if (imageUrl != null && !imageUrl.equals("")) {
                ImageView imageView = (ImageView) findViewById(R.id.advertisement_image);
                if (campaignDetailsModel.triggerType.equalsIgnoreCase(AdType.AD_TYPE_AIRPLANE_MODE_ON.name())) {
                    Picasso.with(this)
                            .load(imageUrl)
                            .networkPolicy(NetworkPolicy.OFFLINE)
                            .into(imageView);
                } else {
                    Picasso.with(this).load(imageUrl).into(imageView);
                }
            } else {
                JioAdsUtil.getInstance().showMessage(getApplicationContext(), "No MediaSet in Campaign....!!");
            }
        } else {
            JioAdsUtil.getInstance().showMessage(getApplicationContext(), "No Campaign....!!");
        }
    }

    private void initListener() {
        findViewById(R.id.close_advertisement).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.advertisement_image).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = campaignDetailsModel.redirectUrl;
                if (url != null) {
                    if (!url.startsWith("http://") && !url.startsWith("https://"))
                        url = "http://" + url;
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(browserIntent);
                    finish();
                }
                JioAdsLoggingUtils.logEvent(Constants.ACTIVITY_TYPE_CLICK, new Date(), campaignDetailsModel, getApplicationContext());
            }
        });
    }
}
