package com.ril.jioads.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by ProBook on 8/8/2017.
 */

public class CampaignDetailsModel implements Parcelable {
    public static final Creator<CampaignDetailsModel> CREATOR = new Creator<CampaignDetailsModel>() {
        @Override
        public CampaignDetailsModel createFromParcel(Parcel in) {
            return new CampaignDetailsModel(in);
        }

        @Override
        public CampaignDetailsModel[] newArray(int size) {
            return new CampaignDetailsModel[size];
        }
    };
    public String campaignTitle;
    public String status;
    public String triggerType;
    public String campaignId;
    public String adFormat;
    public String mediaType;
    public String redirectUrl;
    public String profile;
    public String campaignType;
    public String logo_img_url;
    public String txt_msg;
    public String deep_link_url;
    public String ext_link_url;
    public String mediasetUrl;
    public String scheduleCampMappModelList;
    public ScheduleCampaignModel scheduleCampaign;

    //Unused fields
    private String triggeredBy;
    private int mediasetId;
    private String selectedDays;
    private String triggerName;
    private String minCallDuration;
    private String usersRoaming;
    private String headerText;
    private String advertisementText;
    private String offertext;
    private String appName;
    private String advertiser;
    private String deliveryType;
    private String remark;
    private String profileQueries;
    private String platform;
    private String addinfo1;
    private String addinfo2;
    private String addinfo3;
    private String addinfo4;
    private String profileQuery;
    private String title;
    protected CampaignDetailsModel(Parcel in) {
        campaignTitle = in.readString();
        status = in.readString();
        triggerType = in.readString();
        triggeredBy = in.readString();
        campaignId = in.readString();
        mediasetId = in.readInt();
        selectedDays = in.readString();
        triggerName = in.readString();
        minCallDuration = in.readString();
        usersRoaming = in.readString();
        headerText = in.readString();
        advertisementText = in.readString();
        adFormat = in.readString();
        mediaType = in.readString();
        redirectUrl = in.readString();
        offertext = in.readString();
        appName = in.readString();
        advertiser = in.readString();
        deliveryType = in.readString();
        remark = in.readString();
        profile = in.readString();
        profileQueries = in.readString();
        campaignType = in.readString();
        platform = in.readString();
        addinfo1 = in.readString();
        addinfo2 = in.readString();
        addinfo3 = in.readString();
        addinfo4 = in.readString();
        profileQuery = in.readString();
        title = in.readString();
        logo_img_url = in.readString();
        txt_msg = in.readString();
        deep_link_url = in.readString();
        ext_link_url = in.readString();
        mediasetUrl = in.readString();
        scheduleCampMappModelList = in.readString();
        scheduleCampaign = in.readParcelable(ScheduleCampaignModel.class.getClassLoader());
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(campaignTitle);
        dest.writeString(status);
        dest.writeString(triggerType);
        dest.writeString(triggeredBy);
        dest.writeString(campaignId);
        dest.writeInt(mediasetId);
        dest.writeString(selectedDays);
        dest.writeString(triggerName);
        dest.writeString(minCallDuration);
        dest.writeString(usersRoaming);
        dest.writeString(headerText);
        dest.writeString(advertisementText);
        dest.writeString(adFormat);
        dest.writeString(mediaType);
        dest.writeString(redirectUrl);
        dest.writeString(offertext);
        dest.writeString(appName);
        dest.writeString(advertiser);
        dest.writeString(deliveryType);
        dest.writeString(remark);
        dest.writeString(profile);
        dest.writeString(profileQueries);
        dest.writeString(campaignType);
        dest.writeString(platform);
        dest.writeString(addinfo1);
        dest.writeString(addinfo2);
        dest.writeString(addinfo3);
        dest.writeString(addinfo4);
        dest.writeString(profileQuery);
        dest.writeString(title);
        dest.writeString(logo_img_url);
        dest.writeString(txt_msg);
        dest.writeString(deep_link_url);
        dest.writeString(ext_link_url);
        dest.writeString(mediasetUrl);
        dest.writeString(scheduleCampMappModelList);
        dest.writeParcelable(scheduleCampaign, flags);
    }
}