package com.ril.jioads.model;

/**
 * Created by ProBook on 1/9/2018.
 */

public class EventLogResponseModel {
    public String data;
    public String status;
    public String statusDesc;
}
