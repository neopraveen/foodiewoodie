package com.ril.jioads.utils;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.Toast;

import com.danikula.videocache.HttpProxyCacheServer;
import com.google.gson.Gson;
import com.ril.jioads.activities.JioAudioAdsActivity;
import com.ril.jioads.activities.JioImageAdsActivity;
import com.ril.jioads.activities.JioVideoAdsActivity;
import com.ril.jioads.constants.AdType;
import com.ril.jioads.constants.Constants;
import com.ril.jioads.cryptoutils.AesUtil;
import com.ril.jioads.listeners.UserCompleteDetails;
import com.ril.jioads.model.ActiveCampaignModel;
import com.ril.jioads.model.ActiveCampaignResponseModel;
import com.ril.jioads.model.AdsCampaignModel;
import com.ril.jioads.model.AdsRequestDataModel;
import com.ril.jioads.model.ConfigurationModel;
import com.ril.jioads.model.GetActiveCampaignReqModel;
import com.ril.jioads.model.RegisterRequestModel;
import com.ril.jioads.model.RegisterUserResponseModel;
import com.ril.jioads.model.TokenRequestModel;
import com.ril.jioads.model.TokenResponseModel;
import com.ril.jioads.persistence.CampaignHandler;
import com.ril.jioads.persistence.SharedPreferenceStore;
import com.ril.jioads.rest.ApiClient;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.ril.jioads.utils.AdsHelperUtils.getMobileUid;


/**
 * Created by ProBook on 8/2/2017.
 */

public class JioAdsUtil {
    public static final String REQ_FROM = "ANDROID";
    private static final String MOBILE_UID = "";
    private static JioAdsUtil instance;
    private HttpProxyCacheServer proxy;

    public static JioAdsUtil getInstance() {
        if (instance == null)
            instance = new JioAdsUtil();
        return instance;
    }

    public static HttpProxyCacheServer getProxy(Context context) {
        return getInstance().proxy == null ? (getInstance().proxy = getInstance().newProxy(context)) : getInstance().proxy;
    }

    public static boolean captureSystemEvents(Context context) {
        boolean showAdsOnSystemEvents = SharedPreferenceStore.getValue(context, Constants.SHOW_ADS_ON_SYSTEM_EVENTS, false);
        return showAdsOnSystemEvents;
    }

    public static void pt(String title) {
        Log.d("JIOADS", ">>>>>>>>>>>>>> " + title);
    }

    public static void pl(String message) {
        Log.d("JIOADS", message);
    }

    public static String getIMEIID(Context context) {
        return getLastSavedUserDetails(context).getImeiNumber();
    }
//    public void init(Context context, UserCompleteDetails userCompleteDetails) {
//        this.init(context, false, userCompleteDetails);
//    }

    public static UserCompleteDetails getLastSavedUserDetails(Context context) {
        String userDetailsString = SharedPreferenceStore.getValue(context, Constants.USER_DETAILS, "");
        if (userDetailsString != null && !userDetailsString.equals(""))
            return new Gson().fromJson(userDetailsString, UserCompleteDetails.class);
        return new UserCompleteDetails();
    }

    public void init(Context context, String appName, String appVersion, String imeiNumber) {
        if (AdsHelperUtils.isEmpty(appName)) {
            showMessage(context, "App Name must not be empty.");
        } else if (AdsHelperUtils.isEmpty(appVersion)) {
            showMessage(context, "App Version must not be empty.");
        } else if (AdsHelperUtils.isEmpty(imeiNumber)) {
            showMessage(context, "IMEI Number must not be empty.");
        } else {
            UserCompleteDetails userCompleteDetails = new UserCompleteDetails();
            userCompleteDetails.setAppName(appName);
            userCompleteDetails.setAppVersion(appVersion);
            userCompleteDetails.setImeiNumber(imeiNumber);
            this.init(context, false, userCompleteDetails);
        }
    }

    private void init(Context context, boolean isForTesting, UserCompleteDetails userCompleteDetails) {
        setTestingEnableDisable(context, isForTesting);
        if (userCompleteDetails != null)
            saveUserDetails(context, userCompleteDetails);
        registerNow(context, userCompleteDetails);
    }

    public void showMessage(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
        Intent intent = new Intent(Constants.ADVERTISEMENT_BROADCAST_EVENTS);
        intent.putExtra("DATA", message);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    private void setTestingEnableDisable(Context context, boolean isForTesting) {
        SharedPreferenceStore.storeValue(context, Constants.TESTING_STATUS, isForTesting);
    }

    public boolean isTestingEnabled(Context context) {
        return SharedPreferenceStore.getValue(context, Constants.TESTING_STATUS, false);
    }

    private void registerNow(final Context context, UserCompleteDetails userCompleteDetails) {
        registerAfterCheckingToken(context, null, userCompleteDetails);
    }

    private void registerAfterCheckingToken(final Context context, final com.ril.jioads.listeners.Callback callback, final UserCompleteDetails userCompleteDetails) {
        String token = AdsHelperUtils.getToken(context);
        if (token != null && !token.equals(""))
            registerUserNow(context, callback, userCompleteDetails);
        else {
            getToken(context, new com.ril.jioads.listeners.Callback() {
                @Override
                public void onSuccess() {
                    registerUserNow(context, callback, userCompleteDetails);
                }

                @Override
                public void onFailure() {
                    showMessage(context, "Token failed");
                }
            });
        }
    }

    private void registerUserNow(final Context context, final com.ril.jioads.listeners.Callback callback, UserCompleteDetails userCompleteDetails) {
        markApiCallStarted(context);
        resetScheduleProfileUpdate(context);
        if (userCompleteDetails == null)
            userCompleteDetails = new UserCompleteDetails();
        RegisterRequestModel registerRequestModel = getUserDetailsForRegistration(context, userCompleteDetails);
        String requestString = new Gson().toJson(registerRequestModel);
        pt("Registration Req");
        pl(requestString);
        AdsRequestDataModel dataModel = new AdsRequestDataModel();
        dataModel.uid = AdsHelperUtils.generateUUID(context, false);
        dataModel.data = AesUtil.encrypt(AdsHelperUtils.getToken(context), requestString);
        pl("Registration Req Encrypted   >>>>>>>>>>>");
        pl(new Gson().toJson(dataModel));
        Call<RegisterUserResponseModel> registerCall = ApiClient.getApiInterFace().registerUser(dataModel);
        registerCall.enqueue(new Callback<RegisterUserResponseModel>() {
            @Override
            public void onResponse(Call<RegisterUserResponseModel> call, Response<RegisterUserResponseModel> response) {
                markApiCallFinished(context);
                if (response.isSuccessful() && response.body() != null) {
                    pt("Registration Req Encrypted");
                    pl(new Gson().toJson(response.body()));
                    registerNowOnSuccess(context, response.body(), callback);
                } else {
                    showMessage(context, "Client Registration Failed..!!");
                    Log.e("DATA", "Error!!");
                    if (callback != null)
                        callback.onFailure();
                }
            }

            @Override
            public void onFailure(Call<RegisterUserResponseModel> call, Throwable t) {
                markApiCallFinished(context);
                showMessage(context, "Client Registration Failed..> " + t.getMessage());
                Log.e("DATA", "Error!! >> " + t.toString());
                if (callback != null)
                    callback.onFailure();
            }
        });
    }

    private RegisterRequestModel getUserDetailsForRegistration(Context context, UserCompleteDetails userCompleteDetails) {
        RegisterRequestModel registerRequestModel = new RegisterRequestModel();
        registerRequestModel.appName = userCompleteDetails.getAppName();//getAppName(context);
        registerRequestModel.imei = userCompleteDetails.getImeiNumber();//getIMEIID(context);
        registerRequestModel.endPointUri = getFBaseToken(context);
        registerRequestModel.mobileUid = getMobileUid(context);
        registerRequestModel.platform = REQ_FROM;
        registerRequestModel.version = userCompleteDetails.getAppVersion();//getAppVersion(context);
        return registerRequestModel;
    }

//    private RegisterRequestModel.RegisterProfile getUserProfile(UserCompleteDetails userCompleteDetails) {
//        RegisterRequestModel.RegisterProfile registerProfile = new RegisterRequestModel.RegisterProfile();
//        registerProfile.circle = userCompleteDetails.getCircle(); //getUserCircle(context);
//        registerProfile.customer_type = userCompleteDetails.getCustomerIsPrime() ? "Prime" : "NonPrime";//getCustomerType(context);
//        registerProfile.platform = REQ_FROM;
//        registerProfile.version = userCompleteDetails.getAppVersion();//getAppVersion(context);
//        return registerProfile;
//    }
//
//    private String getIMSI(Context context) {
//        try {
//            TelephonyManager tel = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
//            String imsi = tel.getSubscriberId().toString();
//            return imsi != null ? imsi : "";
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return "";
//    }

    private String getAppName(Context context) {
        return "MyJio";
    }

    private String getCurrentDate(Context context) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            Date date = new Date();
            return sdf.format(date);
        } catch (Exception e) {
            return "NA";
        }
    }

    public void getToken(final Context context, final com.ril.jioads.listeners.Callback callback) {
        markApiCallStarted(context);
        String deviceIMEIId = getLastSavedUserDetails(context).getImeiNumber();//getIMEIID(context);
        TokenRequestModel tokenRequestModel = new TokenRequestModel(deviceIMEIId, REQ_FROM, AdsHelperUtils.getAppVersion(context), AdsHelperUtils.getApplicationName(context));
        String requestString = new Gson().toJson(tokenRequestModel);
        AdsRequestDataModel dataModel = new AdsRequestDataModel();
        dataModel.uid = AdsHelperUtils.generateUUID(context, true);
        final String edKey = new StringBuilder(dataModel.uid).reverse().toString();
        dataModel.data = AesUtil.encrypt(edKey, requestString);
        Call<TokenResponseModel> getToken = ApiClient.getApiInterFace().getToken(dataModel);
        getToken.enqueue(new Callback<TokenResponseModel>() {
            @Override
            public void onResponse(Call<TokenResponseModel> call, Response<TokenResponseModel> response) {
                markApiCallFinished(context);
                if (response.isSuccessful() && response.body() != null && response.body().status != null && response.body().status.equalsIgnoreCase("success")) {
                    tokenReceived(context, response.body(), edKey);
                    if (callback != null)
                        callback.onSuccess();
                } else {
                    showMessage(context, "Client Registration Failed..!!");
                    if (callback != null)
                        callback.onFailure();
                }
            }

            @Override
            public void onFailure(Call<TokenResponseModel> call, Throwable t) {
                markApiCallFinished(context);
                showMessage(context, "Client Registration Failed..> " + t.getMessage());
                Log.e("DATA", "Error!! >> " + t.toString());
                if (callback != null)
                    callback.onFailure();
            }
        });
    }
//    private String getIMEIID(Context context) {
//        try {
//            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
//            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
//                return "";
//            }
//            return telephonyManager.getDeviceId();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return "";
//    }

    private void tokenReceived(Context context, TokenResponseModel tokenResponseModel, String edKey) {
        try {
            String configurationString = AesUtil.decrypt(edKey, tokenResponseModel.configuration);
            AdsHelperUtils.saveConfiguration(context, new Gson().fromJson(configurationString, ConfigurationModel.class));
            String tokenString = AesUtil.decrypt(edKey, tokenResponseModel.token);
            AdsHelperUtils.saveToken(context, tokenString);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateFireBaseToken(Context context, String updatedToken) {
        String oldFireBaseToken = getFireBaseToken(context);
        if (oldFireBaseToken == null || oldFireBaseToken.equals("") || !oldFireBaseToken.equals(updatedToken)) {
            saveUpdatedFireBaseToken(context, updatedToken);
            if (isApiCallRunning(context))
                scheduleProfileUpdate(context);
            else {
                registerUserNow(context, null, getLastSavedUserDetails(context));
            }
        }
    }

    private void scheduleProfileUpdate(Context context) {
        SharedPreferenceStore.storeValue(context, Constants.SCHEDULE_PROFILE_UPDATE, true);
    }

    private void resetScheduleProfileUpdate(Context context) {
        SharedPreferenceStore.storeValue(context, Constants.SCHEDULE_PROFILE_UPDATE, false);
    }

    private boolean isProfileUpdateScheduled(Context context) {
        return SharedPreferenceStore.getValue(context, Constants.SCHEDULE_PROFILE_UPDATE, false);
    }

    private void saveUpdatedFireBaseToken(Context context, String updatedToken) {
        SharedPreferenceStore.storeValue(context, Constants.FB_TOKEN, updatedToken);
    }

    private String getFireBaseToken(Context context) {
        return SharedPreferenceStore.getValue(context, Constants.FB_TOKEN, "");
    }

    private void markApiCallStarted(Context context) {
        SharedPreferenceStore.storeValue(context, Constants.API_CALL_RUNNING, true);
    }

    private void markApiCallFinished(Context context) {
        SharedPreferenceStore.storeValue(context, Constants.API_CALL_RUNNING, false);
    }

    private boolean isApiCallRunning(Context context) {
        return SharedPreferenceStore.getValue(context, Constants.API_CALL_RUNNING, false);
    }

    private void saveUserDetails(Context context, UserCompleteDetails userCompleteDetails) {
        SharedPreferenceStore.storeValue(context, Constants.USER_DETAILS, new Gson().toJson(userCompleteDetails));
    }

    private void registerNowOnSuccess(Context context, RegisterUserResponseModel response, com.ril.jioads.listeners.Callback callback) {
        try {
            if (response.status.equalsIgnoreCase("success")) {
                String tokenString = AesUtil.decrypt(AdsHelperUtils.getToken(context), response.data);
                pl("Registration Req Encrypted   >>>>>>>>>>>");
                pl(new Gson().toJson(tokenString));
                TokenModel tokenModel = new Gson().fromJson(tokenString, TokenModel.class);
                if (tokenModel != null && tokenModel.status != null && !tokenModel.status.equals("") && tokenModel.token != null && !tokenModel.token.equals("")) {
                    AdsHelperUtils.saveToken(context, tokenModel.token);
                    markUserAsSuccessfullyRegistered(context);
                    showMessage(context, "Client Registration Successful..!!");
                    fetchActiveCampaigns(context);
                    if (callback != null)
                        callback.onSuccess();
                } else {
                    showMessage(context, "Client Registration Failed..!!");
                    if (callback != null)
                        callback.onFailure();
                }
            } else if (response.statusDesc != null && response.statusDesc.equalsIgnoreCase("Invalid Token")) {
                AdsHelperUtils.resetToken(context);
                JioAdsUtil.getInstance().getToken(context, null);
                showMessage(context, "Client Registration Failed..!!");
            } else {
                showMessage(context, "Client Registration Failed..!!");
                if (callback != null)
                    callback.onFailure();
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (callback != null)
                callback.onFailure();
        }
    }

    private String getFBaseToken(Context context) {
        return SharedPreferenceStore.getValue(context, Constants.FB_TOKEN, "");
    }

    private void markUserAsSuccessfullyRegistered(Context context) {
        AdsHelperUtils.clientRegisteredSuccessfully(context);
    }

    public void showAds(Context context, AdType adType) {
        showAds(context, adType, null);
    }

    public void showAds(Context context, AdType adType, String supportData) {
        List<AdsCampaignModel> campaignDetailsModelList = CampaignHandler.getAvailableCampaigns(context);
        if (campaignDetailsModelList != null) {
            AdsCampaignModel campaignDetailsModel = null;
            for (AdsCampaignModel campaignModel : campaignDetailsModelList) {
                if (campaignModel.triggerType != null && campaignModel.triggerType.toLowerCase().contains(adType.adType.toLowerCase())
                        && JioAdsTrackingUtils.getInstance().isCampaignAvailableAtThisTime(campaignModel)
                        && JioAdsTrackingUtils.getInstance().isCampaignCounterStillRemain(context, campaignModel)) {
                    campaignDetailsModel = campaignModel;
                    break;
                }
            }
            if (campaignDetailsModel != null) {
                showThisCampaignNow(context, campaignDetailsModel);
                showMessage(context, "Showing Campaign..!!");
            } else {
                showMessage(context, "No Campaign available..!!");
            }
        } else {
            showMessage(context, "No Campaign available..!!");
        }
    }

    private void showThisCampaignNow(Context context, AdsCampaignModel campaignDetailsModel) {
        if (campaignDetailsModel.mediaType != null && campaignDetailsModel.mediaType.equalsIgnoreCase("image")) {
            Intent jioAdsIntent = new Intent(context, JioImageAdsActivity.class);
            jioAdsIntent.putExtra(Constants.DATA, campaignDetailsModel);
            jioAdsIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(jioAdsIntent);
        } else if (campaignDetailsModel.mediaType != null && campaignDetailsModel.mediaType.equalsIgnoreCase("video")) {
            Intent jioAdsIntent = new Intent(context, JioVideoAdsActivity.class);
            jioAdsIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            jioAdsIntent.putExtra(Constants.DATA, campaignDetailsModel);
            context.startActivity(jioAdsIntent);
        } else if (campaignDetailsModel.mediaType != null && campaignDetailsModel.mediaType.equalsIgnoreCase("audio")) {
            Intent jioAdsIntent = new Intent(context, JioAudioAdsActivity.class);
            jioAdsIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            jioAdsIntent.putExtra(Constants.DATA, campaignDetailsModel);
            context.startActivity(jioAdsIntent);
        }
    }

    public void fetchActiveCampaigns(final Context context) {
        markApiCallStarted(context);
        String deviceIMEIId = getLastSavedUserDetails(context).getImeiNumber();//getIMEIID(context);
        GetActiveCampaignReqModel tokenRequestModel = new GetActiveCampaignReqModel(deviceIMEIId, "1.1.0", REQ_FROM, getAppName(context));
        String requestString = new Gson().toJson(tokenRequestModel);
        AdsRequestDataModel dataModel = new AdsRequestDataModel();
        dataModel.uid = AdsHelperUtils.generateUUID(context, false);
        final String edKey = AdsHelperUtils.getToken(context);
        dataModel.data = AesUtil.encrypt(edKey, requestString);

        Call<ActiveCampaignResponseModel> registerCall = ApiClient.getApiInterFace().getActiveCampaignDetails(dataModel);
        registerCall.enqueue(new Callback<ActiveCampaignResponseModel>() {
            @Override
            public void onResponse(Call<ActiveCampaignResponseModel> call, Response<ActiveCampaignResponseModel> response) {
                markApiCallFinished(context);
                if (response.isSuccessful() && response.body() != null) {
                    receivedActiveCampaigns(context, response.body());
                } else {
                    showMessage(context, "Error!.. While fetching Campaign..!!");
                    Log.e("DATA", "Error!!");
                }
                if (isProfileUpdateScheduled(context))
                    registerUserNow(context, null, getLastSavedUserDetails(context));
            }

            @Override
            public void onFailure(Call<ActiveCampaignResponseModel> call, Throwable t) {
                markApiCallFinished(context);
                showMessage(context, "Error!.. While fetching Campaign..!!");
                Log.e("DATA", "Error!! >> " + t.toString());
            }
        });
    }

    private void receivedActiveCampaigns(Context context, ActiveCampaignResponseModel activeCampaignResponseModel) {
        if (activeCampaignResponseModel.status != null && !activeCampaignResponseModel.status.equals("") &&
                activeCampaignResponseModel.data != null && !activeCampaignResponseModel.data.equals("")) {
            String tokenString = AesUtil.decrypt(AdsHelperUtils.getToken(context), activeCampaignResponseModel.data);
            ActiveCampaignModel activeCampaignModel = new Gson().fromJson(tokenString, ActiveCampaignModel.class);
            AdsHelperUtils.saveToken(context, activeCampaignModel.token);
            CampaignHandler.saveCampaigns(context, activeCampaignModel.activeCampaigns);
            showMessage(context, activeCampaignModel.activeCampaigns != null ? activeCampaignModel.activeCampaigns.size() + "" : "0");
        }
    }

    private HttpProxyCacheServer newProxy(Context context) {
        return new HttpProxyCacheServer(context);
    }

    class TokenModel {
        String status;
        String token;
    }

}