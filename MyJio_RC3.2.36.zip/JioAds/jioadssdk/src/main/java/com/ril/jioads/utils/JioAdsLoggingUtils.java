package com.ril.jioads.utils;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.ril.jioads.cryptoutils.AesUtil;
import com.ril.jioads.model.AdsCampaignModel;
import com.ril.jioads.model.AdsRequestDataModel;
import com.ril.jioads.model.CampaignDetailsModel;
import com.ril.jioads.model.EventDetailsModel;
import com.ril.jioads.model.EventLogResponseModel;
import com.ril.jioads.model.NotificationModel;
import com.ril.jioads.rest.ApiClient;

import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by ProBook on 8/31/2017.
 */

public class JioAdsLoggingUtils {
    public static void logEvent(String activity, Date date, AdsCampaignModel campaignDetailsModel, Context context) {
        EventDetailsModel eventDetailsModel = new EventDetailsModel();
        eventDetailsModel.imei = JioAdsUtil.getIMEIID(context);
        eventDetailsModel.appName = AdsHelperUtils.getApplicationName(context);
        eventDetailsModel.setCapturedInAppEvents(activity, campaignDetailsModel, date);
        logEvent(context, eventDetailsModel);
    }

    public static void logEvent(String activity, Date date, List<CampaignDetailsModel> campaignDetailsModels, Context context) {
        EventDetailsModel eventDetailsModel = new EventDetailsModel();
        eventDetailsModel.imei = JioAdsUtil.getIMEIID(context);
        eventDetailsModel.appName = AdsHelperUtils.getApplicationName(context);
        eventDetailsModel.setCapturedInAppEvents(activity, campaignDetailsModels, date);
        logEvent(context, eventDetailsModel);
    }

    public static void logAvailableEvents(Context context) {

    }

    public static void logEvent(final Context context, EventDetailsModel eventDetailsModel) {
        String requestString = new Gson().toJson(eventDetailsModel);
        AdsRequestDataModel dataModel = new AdsRequestDataModel();
        dataModel.uid = AdsHelperUtils.generateUUID(context, false);
        dataModel.data = AesUtil.encrypt(AdsHelperUtils.getToken(context), requestString);
        Call<EventLogResponseModel> registerCall = ApiClient.getApiInterFace().logEvent(dataModel);
        registerCall.enqueue(new Callback<EventLogResponseModel>() {
            @Override
            public void onResponse(Call<EventLogResponseModel> call, Response<EventLogResponseModel> response) {
                if (response.isSuccessful() && response.body() != null) {
                    loggingSuccess(context, response.body());
                } else {
                    JioAdsUtil.getInstance().showMessage(context, "Logging event Failed..!!");
                    Log.e("DATA", "Error!!");
                }
            }

            @Override
            public void onFailure(Call<EventLogResponseModel> call, Throwable t) {
                JioAdsUtil.getInstance().showMessage(context, "Logging event Failed..!!..> " + t.getMessage());
                Log.e("DATA", "Error!! >> " + t.toString());
            }
        });
    }

    private static void loggingSuccess(Context context, EventLogResponseModel response) {
        try {
            if (response.status.equalsIgnoreCase("success")) {
                String tokenString = AesUtil.decrypt(AdsHelperUtils.getToken(context), response.data);
                JioAdsUtil.TokenModel tokenModel = new Gson().fromJson(tokenString, JioAdsUtil.TokenModel.class);
                if (tokenModel != null && tokenModel.status != null && !tokenModel.status.equals("") && tokenModel.token != null && !tokenModel.token.equals("")) {
                    AdsHelperUtils.saveToken(context, tokenModel.token);
                } else {
                    JioAdsUtil.getInstance().showMessage(context, "Logging event Failed..!!");
                }
            } else if (response.statusDesc != null && response.statusDesc.equalsIgnoreCase("Invalid Token")) {
                AdsHelperUtils.resetToken(context);
                JioAdsUtil.getInstance().getToken(context, null);
                JioAdsUtil.getInstance().showMessage(context, "Client Registration Failed..!!");
            } else {
                JioAdsUtil.getInstance().showMessage(context, "Logging event Failed..!!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JioAdsUtil.getInstance().showMessage(context, "Logging event Failed..!!");
        }
    }

    public static void logEvent(String activityType, Date date, NotificationModel notificationModel, Context applicationContext) {

    }
}
