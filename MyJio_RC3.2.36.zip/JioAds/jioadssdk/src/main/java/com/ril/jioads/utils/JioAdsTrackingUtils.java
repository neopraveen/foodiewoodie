package com.ril.jioads.utils;

import android.content.Context;

import com.ril.jioads.constants.Constants;
import com.ril.jioads.model.AdsCampaignModel;
import com.ril.jioads.model.AdsCampaignScheduleModel;
import com.ril.jioads.model.CampaignDetailsModel;
import com.ril.jioads.persistence.SharedPreferenceStore;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by ProBook on 8/29/2017.
 */

public class JioAdsTrackingUtils {
    private static JioAdsTrackingUtils jioAdsTrackingUtils;

    public static JioAdsTrackingUtils getInstance() {
        if (jioAdsTrackingUtils == null)
            jioAdsTrackingUtils = new JioAdsTrackingUtils();
        return jioAdsTrackingUtils;
    }

    public boolean isCampaignAvailableAtThisTime(AdsCampaignModel campaignDetailsModel) {
        String endDateString = campaignDetailsModel.scheduleCampaign.scheduleCampaignTime[0].enddate;
        if (endDateString == null || endDateString.equals(""))
            endDateString = campaignDetailsModel.scheduleCampaign.scheduleCampaignTime[0].startdate;
        String endTimeString = campaignDetailsModel.scheduleCampaign.scheduleCampaignTime[0].endtime;
        if (endTimeString == null || endTimeString.equals(""))
            endTimeString = "23:59";
        Date startDate = getStartDateObject(campaignDetailsModel.scheduleCampaign.scheduleCampaignTime[0].startdate, campaignDetailsModel.scheduleCampaign.scheduleCampaignTime[0].starttime);
        Date endDate = getStartDateObject(endDateString, endTimeString);
        Date currentDateTime = Calendar.getInstance().getTime();
        if (startDate != null && endDate != null && currentDateTime.after(startDate) && currentDateTime.before(endDate)) {
            return true;
        }
        return false;
    }

    private Date getStartDateObject(String date, String time) {
        String dateString = date + " " + time;
        DateFormat df = new SimpleDateFormat("MM-dd-yyyy hh:mm");
        Date dateObject;
        try {
            dateObject = df.parse(dateString);
            return dateObject;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean isCampaignCounterStillRemain(Context context, AdsCampaignModel campaignDetailsModel) {
        int currentCounter = SharedPreferenceStore.getValue(context, Constants.CAMPAIGN_COUNTER_PRE + campaignDetailsModel.campaignId, 0);
        if (campaignDetailsModel.scheduleCampaign != null) {
            int freq = getFrequency(campaignDetailsModel.scheduleCampaign);
            if (currentCounter < freq)
                return true;
        }
        return false;
    }

    private int getFrequency(AdsCampaignScheduleModel scheduleCampaign) {
        if (scheduleCampaign.campaignFrequency != null) {
            try {
                return Integer.parseInt(scheduleCampaign.campaignFrequency);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        return 2;
    }

    public void showingCampaign(Context context, AdsCampaignModel adsCampaignModel) {
        int currentCounter = SharedPreferenceStore.getValue(context, Constants.CAMPAIGN_COUNTER_PRE + adsCampaignModel.campaignId, 0);
        SharedPreferenceStore.storeValue(context, Constants.CAMPAIGN_COUNTER_PRE + adsCampaignModel.campaignId, ++currentCounter);
    }
}
