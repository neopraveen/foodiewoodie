package com.ril.jio.oseventlistner.utility;

import android.content.Context;
import android.content.SharedPreferences;


public class PreferenceHelper {

    public static PreferenceHelper preferenceHelper;
    public static String DEFAULT_PREFERENCE = "default_pref";

    private PreferenceHelper() {

    }

    public static PreferenceHelper getPreferenceHelperInstance() {

        synchronized (PreferenceHelper.class) {
            if (preferenceHelper != null) {
                return preferenceHelper;
            }
            return preferenceHelper = new PreferenceHelper();
        }
    }

    public void saveStringPreference(Context context, String preferenceName, String keyName, String value) {

        SharedPreferences sharedPreferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
        SharedPreferences.Editor sharedPreferenceEditor = sharedPreferences.edit();
        sharedPreferenceEditor.putString(keyName, value);
        sharedPreferenceEditor.apply();
    }


    public String getStringPreference(Context context, String preferenceName, String keyName) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
        return sharedPreferences.getString(keyName, "");

    }

    public String getStringPreference(Context context, String keyName) {
        return getStringPreference(context, DEFAULT_PREFERENCE, keyName);
    }

    public void saveStringPreference(Context context, String keyName, String value) {

        saveStringPreference(context, DEFAULT_PREFERENCE, keyName, value);
    }


    public void saveBooleanPreference(Context context, String preferenceName, String keyName, boolean value) {

        SharedPreferences sharedPreferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
        SharedPreferences.Editor sharedPreferenceEditor = sharedPreferences.edit();
        sharedPreferenceEditor.putBoolean(keyName, value);
        sharedPreferenceEditor.apply();
    }


    public boolean getBooleanPreference(Context context, String preferenceName, String keyName) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(keyName, false);

    }

    public boolean getBooleanPreference(Context context, String keyName) {
        return getBooleanPreference(context, DEFAULT_PREFERENCE, keyName);
    }

    public void saveBooleanPreference(Context context, String keyName, boolean value) {

        saveBooleanPreference(context, DEFAULT_PREFERENCE, keyName, value);
    }


    public class Key {

        public static final String END_CALL = "end_call";
        public static final String END_CALL_TO_A_SPECIFIC_NUMBER = "end_call_number";
        public static final String DEVICE_UNPLUGGED_FROM_CHARGING = "device_unplugged_from_charging";
        public static final String WIFI_LATCHING = "wifi_latching";
        public static final String WIFI_LATCHING_TO_A_NAME = "wifi_latching_to_name";
        public static final String DEVICE_REBOOT = "device_reboot";
        public static final String AIRPLANE_MODE = "airplane_mode";
        public static final String DEVICE_UNLOOK_SCREEN = "device_unlock_screen";
        public static final String SMS = "sms";
        public static final String ROAMING = "roaming";
    }
}
