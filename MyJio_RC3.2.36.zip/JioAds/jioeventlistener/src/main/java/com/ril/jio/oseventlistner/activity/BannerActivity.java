package com.ril.jio.oseventlistner.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.ril.jio.oseventlistner.R;
import com.ril.jio.oseventlistner.model.EventData;

/**
 * Created by Administrator on 7/31/2017.
 */

public class BannerActivity extends AppCompatActivity {

    private EventData eventData;
    private AlertDialog alertDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        eventData = (EventData) getIntent().getSerializableExtra("data");
        showAlert();
    }

    Vibrator mVibrate = null;

    private void showAlert() {

        mVibrate = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        long pattern[] = {0, 800, 200, 1200, 300, 2000, 400, 4000};
        mVibrate.vibrate(pattern, -1);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.alert_banner, null);
        initUI(view);
        builder.setView(view);
        builder.setCancelable(false);

        alertDialog = builder.create();

        alertDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                if (mVibrate != null)
                    mVibrate.cancel();
                finish();
            }
        });
        alertDialog.show();
    }

    private void initUI(View view) {

        ((TextView) view.findViewById(R.id.eventname)).setText(eventData.getName() + "\n" + eventData.getData());
        view.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (alertDialog != null) {
                    alertDialog.dismiss();
                    if (mVibrate != null)
                        mVibrate.cancel();
                    finish();
                }
            }
        });
    }
}
