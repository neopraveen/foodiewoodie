package com.ril.jio.oseventlistner.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by Administrator on 8/2/2017.
 */

public class OutGoingCalls extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        String number = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);



    }
}
