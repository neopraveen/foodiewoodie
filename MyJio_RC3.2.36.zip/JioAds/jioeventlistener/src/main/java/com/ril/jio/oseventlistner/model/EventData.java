package com.ril.jio.oseventlistner.model;

import java.io.Serializable;

/**
 * Created by Administrator on 7/31/2017.
 */

public class EventData implements Serializable {
    private String name;
    private String data;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
