package jioads.com.jioads.sample;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.ril.jioads.activities.SurveyActivity;
import com.ril.jioads.constants.AdType;
import com.ril.jioads.constants.Constants;
import com.ril.jioads.utils.JioAdsUtil;

import jioads.com.jioads.R;

public class SampleActivity extends AppCompatActivity {
    private static final int PERMISSION_LOCATION_REQUEST_CODE = 111;
    TextView statusView;
    View.OnClickListener consumeAdsClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.consume_ads_0:
                    consumeAdsClicked();
                    break;
                case R.id.fetch_campaigns:
                    fetchAllActiveCampaigns();
                    break;
                case R.id.show_ads:
                    showAds();
                    break;
                case R.id.consume_ads_3:
                    consumeAdsClicked();
                    break;
                case R.id.show_ads_0:
                    showingSurvey();
                    break;
                default:
                    break;
            }
        }
    };
    View.OnClickListener showAdsClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.show_ads_0:
                    showingSurvey();
                    break;
                case R.id.show_ads_1:
                    showAdsClicked();
                    break;
                case R.id.show_ads_2:
                    showAdsClicked();
                    break;
                case R.id.show_ads_3:
                    showAdsClicked();
                    break;
                default:
                    break;
            }
        }
    };
    BroadcastReceiver jioAdsEventReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String data = intent.getStringExtra("DATA");
            if (data != null) {
                updateStatus(data);
            }
        }
    };
    boolean dataLoadingNotDone = true;

    private void updateStatus(final String data) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                statusView.setText(data);
            }
        });
    }

    private void showAds() {
        JioAdsUtil.getInstance().showAds(this, AdType.AD_TYPE_RECHARGE);
    }

    private void fetchAllActiveCampaigns() {
        JioAdsUtil.getInstance().fetchActiveCampaigns(this);
    }

    private void showAdsClicked() {

    }

    private void showMessageForLoading() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (dataLoadingNotDone)
                    Toast.makeText(getApplicationContext(), "Loading... Please wait!", Toast.LENGTH_SHORT);
            }
        }, 5 * 1000);
    }

    private void showingSurvey() {
        Intent intent = new Intent(this, SurveyActivity.class);
        startActivity(intent);
    }

    private void consumeAdsClicked() {

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkForPermission();
    }

    private void initPage() {
        initListeners();
        //SDK Initialisation
        JioAdsUtil.getInstance().init(getApplicationContext(), "MyJio", "1.1.0", getIMEIID(getApplicationContext()));
        initUI();
    }

    private String getIMEIID(Context context) {
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                return "";
            }
            return telephonyManager.getDeviceId();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private void checkForPermission() {
        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.READ_PHONE_STATE},
                    PERMISSION_LOCATION_REQUEST_CODE);
        } else {
            initPage();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.READ_PHONE_STATE},
                    PERMISSION_LOCATION_REQUEST_CODE);
        } else {
            initPage();
        }
    }

    //    private void initService() {
//        Intent intent = new Intent(this, OSEventListenerService.class);
//        startService(intent);
//    }
//
    private void initUI() {
        statusView = (TextView) findViewById(R.id.dashboard);
    }

    private void initListeners() {
        int[] consumeAdsClickButtonIds = {R.id.consume_ads_0, R.id.fetch_campaigns, R.id.show_ads, R.id.consume_ads_3, R.id.show_ads_0};
        for (int buttonId : consumeAdsClickButtonIds)
            findViewById(buttonId).setOnClickListener(consumeAdsClickListener);
    }

    @Override
    protected void onStart() {
        super.onStart();
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(jioAdsEventReceiver, new IntentFilter(Constants.ADVERTISEMENT_BROADCAST_EVENTS));
    }

    @Override
    protected void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(jioAdsEventReceiver);
    }
}
